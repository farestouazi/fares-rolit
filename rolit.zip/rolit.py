         #++++++++++++++++++++++++++++++++#
         #---UNIVERSITE--GUSTAVE EIFFEL---#
         #-----------2024--2025-----------#
         #++++++++++++++++++++++++++++++++#  

              ####                ####
               #####            #####
         #       #####        #####       #                               
         ####      ##############      ####
         #####        ########        #####
          #####                      #####
            #####       ####       #####
              ####     ######     ####
              ####    ########    ####
              ####     ######     ####
            #####       ####       #####
          #####                      #####
         #####        ########        #####
         ####      ##############      ####
         #       #####        #####       #
               #####            #####
              ####                ####
         
         #++++++++++++++++++++++++++++++++#
         #--------------------------------#
         #++++++++++++++++++++++++++++++++#

######################################################

#++++++++++++++++++++++++++++++++++++++++++++++++++++#
#----------------------------------------------------#
#----------------------ROLIT-------------------------#
#----------------------------------------------------#
#-----------Projet-AP1 ----- S1-2024/2025------------#
#----------------------------------------------------#
#-----------------Groupe TP7 - gr8-------------------#
#----------------------------------------------------#
#------------------------De :------------------------#
#-------------------Elies  Zribi---------------------#
#-------------------Fares  Touazi--------------------#
#-------------------Badis  Halil---------------------#
#----------------------------------------------------#
#---------------Tous droits reserves-----------------#
#-------------------Janvier 2025---------------------#
#----------------------------------------------------#
#++++++++++++++++++++++++++++++++++++++++++++++++++++#

######################################################

#++++++++++++++++++++++++++++++++++++++++++++++++++++#
#--------------------- IMPORTS ----------------------#
#++++++++++++++++++++++++++++++++++++++++++++++++++++#

import fltk, random, copy, ast, time, json, pyautogui

#++++++++++++++++++++++++++++++++++++++++++++++++++++#
#------------------- CONFIGURATION ------------------#
#++++++++++++++++++++++++++++++++++++++++++++++++++++#

def trouver_taille_ideale() :
    """
    Trouver la taille ideale pour la fenetre fltk du jeu
    par rapport a la taille de l'ecran
    """
    SIZES_SCREEN = [400,500,600,700,800,900,1000,1100,1200]
    for SIZE in SIZES_SCREEN :
        if not pyautogui.onScreen(SIZE, SIZE*4/3) :
            return SIZES_SCREEN[SIZES_SCREEN.index(SIZE)]

def sauvegarder_config(state, filename="config.json"):
    """
    Sauvegarder les paramtres de configuration
    """
    with open(filename, "w") as file:
        json.dump(state, file)

def restaurer_config(filename="config.json"):
    """
    Recuperer les paramtres de configuration
    """
    try:
        with open(filename, "r") as file:
            state = json.load(file)
        return state
    except FileNotFoundError:
        state = {"index_langue": 0, "index_police": 3, "mode_plateau": 0, "mode_boules": 0, "theme_interface": 0}
        sauvegarder_config(state)
        return state
        
taille_fenetre = trouver_taille_ideale()
hauteur_fenetre = taille_fenetre*4/3

configuration = restaurer_config()

#++++++++++++++++++++++++++++++++++++++++++++++++++++#
#-------------------- CONSTANTES --------------------#
#++++++++++++++++++++++++++++++++++++++++++++++++++++#

TOUCHES_POSSIBLES = 'azertyuiopqsdfghjklmwxcvbn0123456789'

POLICE_FONTS = ["Rockwell","Centaur","Jokerman","Candara","Fixedsys"]

IU_LANGUE = ["Francais","English","Espanol","Italiano","Deutsch"]

IU_TEXTE = {'menu_principal_reprendre':['REPRENDRE','RESUME','REANUDAR','RIPRENDERE','FORTSETZEN'],
            'menu_principal_jouer':['JOUER','PLAY','JUGAR','GIOCARE','SPIELEN'],
            'menu_principal_options':['PARAMETRES','SETTINGS','PARAMETROS','PARAMETRI','PARAMETER'],
            'menu_principal_quitter':['QUITTER','EXIT','SALIDA','USCITA','AUSFAHRT'],
            'menu_options_tuto':['Comment jouer ?','How to play ?','Como jugar ?','Come si gioca ?','Wie spielt man ?'],
            'menu_options_credit':['A propos','About','Acerca de','Informazioni','Uber'],
            'menu_options_menu':['MENU','MENU','MENU','MENU','MENU'],
            'menu_options_plateau':['Plateau','Board','Tablero','Tavola','Spielfeld'],
            'menu_options_boules':['Forme','Shape','Forma','Forma','Form'],
            'menu_options_music':['Musique','Music','Musica','Musica','Musik'],
            'menu_options_graphisme':['Graphisme realiste','Realistic graphics','Graficos realistas','Grafica realistica','Realistische Grafik'],
            'menu_options_active':['Oui','Yes','Si','Si','Ja'],
            'menu_options_desactive':['Non','No','No','No','Nein'],
            'menu_options_police':['Police','Font','Fuente','Carattere','Schriftart'],
            'menu_options_langue':['Langue','Language','Idioma','Lingua','Sprache'],
            'menu_options_theme':['Thème','Theme','Tema','Tema','Thema'],
            'menu_prepartie_partie':['Partie locale','Local game','Partida local','Partita locale','Lokales Spiel'],
            'menu_prepartie_njoueurs':['Nombre de joueurs','Number of players','Numero de jugadores','Numero di giocatori','Anzahl der Spieler'],
            'menu_prepartie_lpoints':['Limite de points','Point limit','Límite de puntos','Limite di punti','Punktegrenze'],
            'menu_prepartie_suivant':['SUIVANT','NEXT','SIGUIENTE','SUCCESSIVO','NACHSTE'],
            'jeu_selection_commence':['commence','starts','comienza','inizia','beginnt'],
            'menu_jeu_nmanches':['Manche','Round','Ronda','Mano','Runde'],
            'menu_jeu_retour':['Clic droit pour annuler','Right click to cancel','Clic derecho para cancelar','Clic destro per annullare','Rechtsklick zum Abbrechen'],
            'menu_jeu_continue':['Clic gauche pour continuer','Left click to continue','Clic izquierdo para continuar','Clic sinistro per continuare','Linksklick um fortzufahren'],
            'menu_fin_manche_fini':['Fin de manche','End of round','Fin de ronda','Fine della manche','Rundenende'],
            'menu_fin_manche_scores':['Scores','Scores','Puntuaciones','Punteggi','Punktzahlen'],
            'menu_fin_manche_gagnant':['Gagnant','Winner','Ganador','Vincitore','Gewinner'],
            'menu_fin_manche_suivant':['Suivant','Next','Siguiente','Successivo','Nachste'],
            'menu_fin_manche_quitter':['Quitter','Exit','Salir','Uscire','Verlassen'],
            'menu_fin_partie_fini':['Partie finie','Game over','Juego terminado','Partita finita','Spiel beendet'],
            'menu_fin_partie_gagnant':['Gagnant de la partie','Winner of the game','Ganador del juego','Vincitore del gioco','Gewinner des Spiels'],
            'menu_pause_pause':['Pause','Pause','Pausa','Pausa','Pause'],
            'menu_pause_reprendre':['Reprendre','Resume','Reanudar','Riprendere','Fortsetzen'],
            'menu_pause_options':['Parametres','Settings','Parametros','Parametri','Parameter'],
            'menu_pause_sauvquit':['Sauvegarder et quitter','Save and Quit','Guardar y salir','Salva e esci','Speichern und beenden']}

PLATEAU = [
    (taille_fenetre*0.050, taille_fenetre*0.180),
    (taille_fenetre*0.060, taille_fenetre*0.450),
    (taille_fenetre*0.080, taille_fenetre*0.600),
    (taille_fenetre*0.060, taille_fenetre*0.750),
    (taille_fenetre*0.050, taille_fenetre*1.020),
    (taille_fenetre*0.053, taille_fenetre*1.026),
    (taille_fenetre*0.0615, taille_fenetre*1.0395),
    (taille_fenetre*0.074, taille_fenetre*1.047),
    (taille_fenetre*0.350, taille_fenetre*1.040),
    (taille_fenetre*0.500, taille_fenetre*1.020),
    (taille_fenetre*0.650, taille_fenetre*1.040),
    (taille_fenetre*0.920, taille_fenetre*1.050),
    (taille_fenetre*0.926, taille_fenetre*1.047),
    (taille_fenetre*0.9395, taille_fenetre*1.0395),
    (taille_fenetre*0.947, taille_fenetre*1.026),
    (taille_fenetre*0.950, taille_fenetre*1.020),
    (taille_fenetre*0.940, taille_fenetre*0.750),
    (taille_fenetre*0.920, taille_fenetre*0.600),
    (taille_fenetre*0.940, taille_fenetre*0.450),
    (taille_fenetre*0.950, taille_fenetre*0.180),
    (taille_fenetre*0.947, taille_fenetre*0.173),
    (taille_fenetre*0.9395, taille_fenetre*0.1635),
    (taille_fenetre*0.926, taille_fenetre*0.153),
    (taille_fenetre*0.920, taille_fenetre*0.150),
    (taille_fenetre*0.650, taille_fenetre*0.160),
    (taille_fenetre*0.500, taille_fenetre*0.180),
    (taille_fenetre*0.350, taille_fenetre*0.160),
    (taille_fenetre*0.080, taille_fenetre*0.150),
    (taille_fenetre*0.074, taille_fenetre*0.153),
    (taille_fenetre*0.0615, taille_fenetre*0.1615),
    (taille_fenetre*0.053, taille_fenetre*0.174),
    (taille_fenetre*0.050, taille_fenetre*0.180)
]

CORDONNE_CENTRE_BOULES =  [[[taille_fenetre*0.1325,taille_fenetre*0.2325],[taille_fenetre*0.2375,taille_fenetre*0.2325],[taille_fenetre*0.3425,taille_fenetre*0.2325],[taille_fenetre*0.4475,taille_fenetre*0.2325],[taille_fenetre*0.5525,taille_fenetre*0.2325],[taille_fenetre*0.6575,taille_fenetre*0.2325],[taille_fenetre*0.7625,taille_fenetre*0.2325],[taille_fenetre*0.8675,taille_fenetre*0.2325]],
                           [[taille_fenetre*0.1325,taille_fenetre*0.3375],[taille_fenetre*0.2375,taille_fenetre*0.3375],[taille_fenetre*0.3425,taille_fenetre*0.3375],[taille_fenetre*0.4475,taille_fenetre*0.3375],[taille_fenetre*0.5525,taille_fenetre*0.3375],[taille_fenetre*0.6575,taille_fenetre*0.3375],[taille_fenetre*0.7625,taille_fenetre*0.3375],[taille_fenetre*0.8675,taille_fenetre*0.3375]],
                           [[taille_fenetre*0.1325,taille_fenetre*0.4425],[taille_fenetre*0.2375,taille_fenetre*0.4425],[taille_fenetre*0.3425,taille_fenetre*0.4425],[taille_fenetre*0.4475,taille_fenetre*0.4425],[taille_fenetre*0.5525,taille_fenetre*0.4425],[taille_fenetre*0.6575,taille_fenetre*0.4425],[taille_fenetre*0.7625,taille_fenetre*0.4425],[taille_fenetre*0.8675,taille_fenetre*0.4425]],
                           [[taille_fenetre*0.1325,taille_fenetre*0.5475],[taille_fenetre*0.2375,taille_fenetre*0.5475],[taille_fenetre*0.3425,taille_fenetre*0.5475],[taille_fenetre*0.4475,taille_fenetre*0.5475],[taille_fenetre*0.5525,taille_fenetre*0.5475],[taille_fenetre*0.6575,taille_fenetre*0.5475],[taille_fenetre*0.7625,taille_fenetre*0.5475],[taille_fenetre*0.8675,taille_fenetre*0.5475]],
                           [[taille_fenetre*0.1325,taille_fenetre*0.6525],[taille_fenetre*0.2375,taille_fenetre*0.6525],[taille_fenetre*0.3425,taille_fenetre*0.6525],[taille_fenetre*0.4475,taille_fenetre*0.6525],[taille_fenetre*0.5525,taille_fenetre*0.6525],[taille_fenetre*0.6575,taille_fenetre*0.6525],[taille_fenetre*0.7625,taille_fenetre*0.6525],[taille_fenetre*0.8675,taille_fenetre*0.6525]],
                           [[taille_fenetre*0.1325,taille_fenetre*0.7575],[taille_fenetre*0.2375,taille_fenetre*0.7575],[taille_fenetre*0.3425,taille_fenetre*0.7575],[taille_fenetre*0.4475,taille_fenetre*0.7575],[taille_fenetre*0.5525,taille_fenetre*0.7575],[taille_fenetre*0.6575,taille_fenetre*0.7575],[taille_fenetre*0.7625,taille_fenetre*0.7575],[taille_fenetre*0.8675,taille_fenetre*0.7575]],
                           [[taille_fenetre*0.1325,taille_fenetre*0.8625],[taille_fenetre*0.2375,taille_fenetre*0.8625],[taille_fenetre*0.3425,taille_fenetre*0.8625],[taille_fenetre*0.4475,taille_fenetre*0.8625],[taille_fenetre*0.5525,taille_fenetre*0.8625],[taille_fenetre*0.6575,taille_fenetre*0.8625],[taille_fenetre*0.7625,taille_fenetre*0.8625],[taille_fenetre*0.8675,taille_fenetre*0.8625]],
                           [[taille_fenetre*0.1325,taille_fenetre*0.9675],[taille_fenetre*0.2375,taille_fenetre*0.9675],[taille_fenetre*0.3425,taille_fenetre*0.9675],[taille_fenetre*0.4475,taille_fenetre*0.9675],[taille_fenetre*0.5525,taille_fenetre*0.9675],[taille_fenetre*0.6575,taille_fenetre*0.9675],[taille_fenetre*0.7625,taille_fenetre*0.9675],[taille_fenetre*0.8675,taille_fenetre*0.9675]]]

CORDONNE_CENTRE_BOULES_DE_COTES =   [[taille_fenetre*0.500,taille_fenetre*0.055],
                                     [taille_fenetre*0.945,taille_fenetre*0.500],
                                     [taille_fenetre*0.500,taille_fenetre*0.945],
                                     [taille_fenetre*0.055,taille_fenetre*0.500]]

CORDONNE_CENTRE_MINI_BOULES_DE_COTES =  [[[taille_fenetre*0.400,taille_fenetre*0.155],[taille_fenetre*0.600,taille_fenetre*0.155]],
                                         [[taille_fenetre*0.945,taille_fenetre*0.500],[taille_fenetre*0.945,taille_fenetre*0.700]],
                                         [[taille_fenetre*0.400,taille_fenetre*1.045],[taille_fenetre*0.600,taille_fenetre*1.045]],
                                         [[taille_fenetre*0.055,taille_fenetre*0.500],[taille_fenetre*0.055,taille_fenetre*0.700]]]

CORDONNE_SOURIS = [
    [
        [[taille_fenetre*0.080, taille_fenetre*0.180], [taille_fenetre*0.185, taille_fenetre*0.285]], 
        [[taille_fenetre*0.185, taille_fenetre*0.180], [taille_fenetre*0.290, taille_fenetre*0.285]], 
        [[taille_fenetre*0.290, taille_fenetre*0.180], [taille_fenetre*0.395, taille_fenetre*0.285]], 
        [[taille_fenetre*0.395, taille_fenetre*0.180], [taille_fenetre*0.500, taille_fenetre*0.285]], 
        [[taille_fenetre*0.500, taille_fenetre*0.180], [taille_fenetre*0.605, taille_fenetre*0.285]], 
        [[taille_fenetre*0.605, taille_fenetre*0.180], [taille_fenetre*0.710, taille_fenetre*0.285]], 
        [[taille_fenetre*0.710, taille_fenetre*0.180], [taille_fenetre*0.815, taille_fenetre*0.285]], 
        [[taille_fenetre*0.815, taille_fenetre*0.180], [taille_fenetre*0.920, taille_fenetre*0.285]]
    ],
    
    [
        [[taille_fenetre*0.080, taille_fenetre*0.285], [taille_fenetre*0.185, taille_fenetre*0.390]], 
        [[taille_fenetre*0.185, taille_fenetre*0.285], [taille_fenetre*0.290, taille_fenetre*0.390]], 
        [[taille_fenetre*0.290, taille_fenetre*0.285], [taille_fenetre*0.395, taille_fenetre*0.390]], 
        [[taille_fenetre*0.395, taille_fenetre*0.285], [taille_fenetre*0.500, taille_fenetre*0.390]], 
        [[taille_fenetre*0.500, taille_fenetre*0.285], [taille_fenetre*0.605, taille_fenetre*0.390]], 
        [[taille_fenetre*0.605, taille_fenetre*0.285], [taille_fenetre*0.710, taille_fenetre*0.390]], 
        [[taille_fenetre*0.710, taille_fenetre*0.285], [taille_fenetre*0.815, taille_fenetre*0.390]], 
        [[taille_fenetre*0.815, taille_fenetre*0.285], [taille_fenetre*0.920, taille_fenetre*0.390]]
    ],

    [
        [[taille_fenetre*0.080, taille_fenetre*0.390], [taille_fenetre*0.185, taille_fenetre*0.495]], 
        [[taille_fenetre*0.185, taille_fenetre*0.390], [taille_fenetre*0.290, taille_fenetre*0.495]], 
        [[taille_fenetre*0.290, taille_fenetre*0.390], [taille_fenetre*0.395, taille_fenetre*0.495]], 
        [[taille_fenetre*0.395, taille_fenetre*0.390], [taille_fenetre*0.500, taille_fenetre*0.495]], 
        [[taille_fenetre*0.500, taille_fenetre*0.390], [taille_fenetre*0.605, taille_fenetre*0.495]], 
        [[taille_fenetre*0.605, taille_fenetre*0.390], [taille_fenetre*0.710, taille_fenetre*0.495]], 
        [[taille_fenetre*0.710, taille_fenetre*0.390], [taille_fenetre*0.815, taille_fenetre*0.495]], 
        [[taille_fenetre*0.815, taille_fenetre*0.390], [taille_fenetre*0.920, taille_fenetre*0.495]]
    ],

    [
        [[taille_fenetre*0.080, taille_fenetre*0.495], [taille_fenetre*0.185, taille_fenetre*0.600]], 
        [[taille_fenetre*0.185, taille_fenetre*0.495], [taille_fenetre*0.290, taille_fenetre*0.600]], 
        [[taille_fenetre*0.290, taille_fenetre*0.495], [taille_fenetre*0.395, taille_fenetre*0.600]], 
        [[taille_fenetre*0.395, taille_fenetre*0.495], [taille_fenetre*0.500, taille_fenetre*0.600]], 
        [[taille_fenetre*0.500, taille_fenetre*0.495], [taille_fenetre*0.605, taille_fenetre*0.600]], 
        [[taille_fenetre*0.605, taille_fenetre*0.495], [taille_fenetre*0.710, taille_fenetre*0.600]], 
        [[taille_fenetre*0.710, taille_fenetre*0.495], [taille_fenetre*0.815, taille_fenetre*0.600]], 
        [[taille_fenetre*0.815, taille_fenetre*0.495], [taille_fenetre*0.920, taille_fenetre*0.600]]
    ],

    [
        [[taille_fenetre*0.080, taille_fenetre*0.600], [taille_fenetre*0.185, taille_fenetre*0.705]], 
        [[taille_fenetre*0.185, taille_fenetre*0.600], [taille_fenetre*0.290, taille_fenetre*0.705]], 
        [[taille_fenetre*0.290, taille_fenetre*0.600], [taille_fenetre*0.395, taille_fenetre*0.705]], 
        [[taille_fenetre*0.395, taille_fenetre*0.600], [taille_fenetre*0.500, taille_fenetre*0.705]], 
        [[taille_fenetre*0.500, taille_fenetre*0.600], [taille_fenetre*0.605, taille_fenetre*0.705]], 
        [[taille_fenetre*0.605, taille_fenetre*0.600], [taille_fenetre*0.710, taille_fenetre*0.705]], 
        [[taille_fenetre*0.710, taille_fenetre*0.600], [taille_fenetre*0.815, taille_fenetre*0.705]], 
        [[taille_fenetre*0.815, taille_fenetre*0.600], [taille_fenetre*0.920, taille_fenetre*0.705]]
    ],

    [
        [[taille_fenetre*0.080, taille_fenetre*0.705], [taille_fenetre*0.185, taille_fenetre*0.810]], 
        [[taille_fenetre*0.185, taille_fenetre*0.705], [taille_fenetre*0.290, taille_fenetre*0.810]], 
        [[taille_fenetre*0.290, taille_fenetre*0.705], [taille_fenetre*0.395, taille_fenetre*0.810]], 
        [[taille_fenetre*0.395, taille_fenetre*0.705], [taille_fenetre*0.500, taille_fenetre*0.810]], 
        [[taille_fenetre*0.500, taille_fenetre*0.705], [taille_fenetre*0.605, taille_fenetre*0.810]], 
        [[taille_fenetre*0.605, taille_fenetre*0.705], [taille_fenetre*0.710, taille_fenetre*0.810]], 
        [[taille_fenetre*0.710, taille_fenetre*0.705], [taille_fenetre*0.815, taille_fenetre*0.810]], 
        [[taille_fenetre*0.815, taille_fenetre*0.705], [taille_fenetre*0.920, taille_fenetre*0.810]]
    ],

    [
        [[taille_fenetre*0.080, taille_fenetre*0.810], [taille_fenetre*0.185, taille_fenetre*0.915]], 
        [[taille_fenetre*0.185, taille_fenetre*0.810], [taille_fenetre*0.290, taille_fenetre*0.915]], 
        [[taille_fenetre*0.290, taille_fenetre*0.810], [taille_fenetre*0.395, taille_fenetre*0.915]], 
        [[taille_fenetre*0.395, taille_fenetre*0.810], [taille_fenetre*0.500, taille_fenetre*0.915]], 
        [[taille_fenetre*0.500, taille_fenetre*0.810], [taille_fenetre*0.605, taille_fenetre*0.915]], 
        [[taille_fenetre*0.605, taille_fenetre*0.810], [taille_fenetre*0.710, taille_fenetre*0.915]], 
        [[taille_fenetre*0.710, taille_fenetre*0.810], [taille_fenetre*0.815, taille_fenetre*0.915]], 
        [[taille_fenetre*0.815, taille_fenetre*0.810], [taille_fenetre*0.920, taille_fenetre*0.915]]
    ],
    
    [
        [[taille_fenetre*0.080, taille_fenetre*0.915], [taille_fenetre*0.185, taille_fenetre*1.020]], 
        [[taille_fenetre*0.185, taille_fenetre*0.915], [taille_fenetre*0.290, taille_fenetre*1.020]], 
        [[taille_fenetre*0.290, taille_fenetre*0.915], [taille_fenetre*0.395, taille_fenetre*1.020]], 
        [[taille_fenetre*0.395, taille_fenetre*0.915], [taille_fenetre*0.500, taille_fenetre*1.020]], 
        [[taille_fenetre*0.500, taille_fenetre*0.915], [taille_fenetre*0.605, taille_fenetre*1.020]], 
        [[taille_fenetre*0.605, taille_fenetre*0.915], [taille_fenetre*0.710, taille_fenetre*1.020]], 
        [[taille_fenetre*0.710, taille_fenetre*0.915], [taille_fenetre*0.815, taille_fenetre*1.020]], 
        [[taille_fenetre*0.815, taille_fenetre*0.915], [taille_fenetre*0.920, taille_fenetre*1.020]]
    ]
]

CORDONNE_CENTRE_BOULES_COTES = [[taille_fenetre*0.500,taille_fenetre*0.155],
                                [taille_fenetre*0.945,taille_fenetre*0.600],
                                [taille_fenetre*0.500,taille_fenetre*1.045],
                                [taille_fenetre*0.055,taille_fenetre*0.600]]

ENTOURAGE_BOULES = [[[ 2, 9,10],[ 1, 3, 9,10,11],[ 2, 4,10,11,12],[ 3, 5,11,12,13],[ 4, 6,12,13,14],[ 5, 7,13,14,15],[ 6, 8,14,15,16],[ 7,15,16]],
                    [[ 1, 2,10,17,18],[ 1, 2, 3, 9,11,17,18,19],[ 2, 3, 4,10,12,18,19,20],[ 3, 4, 5,11,13,19,20,21],[ 4, 5, 6,12,14,20,21,22],[ 5, 6, 7,13,15,21,22,23],[ 6, 7, 8,14,16,22,23,24],[ 7, 8,15,23,24]],
                    [[ 9,10,18,25,26],[ 9,10,11,17,19,25,26,27],[10,11,12,18,20,26,27,28],[11,12,13,19,21,27,28,29],[12,13,14,20,22,28,29,30],[13,14,15,21,23,29,30,31],[14,15,16,22,24,30,31,32],[15,16,23,31,32]],
                    [[17,18,26,33,34],[17,18,19,25,27,33,34,35],[18,19,20,26,28,34,35,36],[19,20,21,27,29,35,36,37],[20,21,22,28,30,36,37,38],[21,22,23,29,31,37,38,39],[22,23,24,30,32,38,39,40],[23,24,31,39,40]],
                    [[25,26,34,41,42],[25,26,27,33,35,41,42,43],[26,27,28,34,36,42,43,44],[27,28,29,35,37,43,44,45],[28,29,30,36,38,44,45,46],[29,30,31,37,39,45,46,47],[30,31,32,38,40,46,47,48],[31,32,39,47,48]],
                    [[33,34,42,49,50],[33,34,35,41,43,49,50,51],[34,35,36,42,44,50,51,52],[35,36,37,43,45,51,52,53],[36,37,38,44,46,52,53,54],[37,38,39,45,47,53,54,55],[38,39,40,46,48,54,55,56],[39,40,47,55,56]],
                    [[41,42,50,57,58],[41,42,43,49,51,57,58,59],[42,43,44,50,52,58,59,60],[43,44,45,51,53,59,60,61],[44,45,46,52,54,60,61,62],[45,46,47,53,55,61,62,63],[46,47,48,54,56,62,63,64],[47,48,55,63,64]],
                    [[49,50,58],[49,50,51,57,59],[50,51,52,58,60],[51,52,53,59,61],[52,53,54,60,62],[53,54,55,61,63],[54,55,56,62,64],[55,56,63]]]

#++++++++++++++++++++++++++++++++++++++++++++++++++#
#------------------- FONCTIONS --------------------#
#++++++++++++++++++++++++++++++++++++++++++++++++++#

def efface_multiple_objets(objets) :
    """
    Effacer plusieurs objets
    : param objets: ( list ) liste des objets a supprimer
    
    : return: None
    """
    for _ in objets :
        fltk.efface(_)

def boules_sur_plateau(statut) :
    """
    la  fonction renvoie une liste de numéros de boules placés sur le plateaue
    : param statut: ( list ) une liste de listes représentant un plateau provisoire
        portant True s'il y a une boule à cet endroit et False sinon.
    
    : return : ( list ) liste de numéros de boules placés sur le plateau
        chaque numéro est compris entre 1 et 64 et len(list) <= 64.
    
    """
    liste_boules_sur_plateau = []
    
    for i in range(len(statut)) :
        for j in range(len(statut[i])) :
            if statut[i][j] == True :
                liste_boules_sur_plateau.append(8*i+(j+1))
    return liste_boules_sur_plateau

def obtenir_info_clic(statut_boules) :
    """
    Connaitre si il y a une boule sur le champ selectionne ou non
    """
    info = False
    ligne = 0
    colonne = 0
    for i in range(8) :
        for j in range(8) :
            if CORDONNE_SOURIS[i][j][0][0] < fltk.abscisse_souris() < CORDONNE_SOURIS[i][j][1][0] and CORDONNE_SOURIS[i][j][0][1] < fltk.ordonnee_souris() < CORDONNE_SOURIS[i][j][1][1] :
                ligne = i
                colonne = j
            
    for boule in ENTOURAGE_BOULES[ligne][colonne] :
        if boule in boules_sur_plateau(statut_boules) :
            if statut_boules[ligne][colonne] == False :
                info = True
    return info

def poser_boule(couleurs_boules,statut_boules,couleur) :
    """
    Poser une boule sur le plateau dans un champ selectionne
    """
    ligne = 0
    colonne = 0
    for i in range(8) :
        for j in range(8) :
            if CORDONNE_SOURIS[i][j][0][0] < fltk.abscisse_souris() < CORDONNE_SOURIS[i][j][1][0] and CORDONNE_SOURIS[i][j][0][1] < fltk.ordonnee_souris() < CORDONNE_SOURIS[i][j][1][1] :
                ligne = i
                colonne = j
    for boule in ENTOURAGE_BOULES[ligne][colonne] :
        if boule in boules_sur_plateau(statut_boules) :
            if statut_boules[ligne][colonne] == False :
                couleurs_boules[ligne][colonne] = couleur
                statut_boules[ligne][colonne] = True
                check_boules(couleurs_boules,ligne,colonne,couleur)

def poser_boule_aleatoire(couleurs_boules,statut_boules,couleur) :
    """
    Poser une boule automatiquement si la partie est contre la machine ( CPU )
    """
    while True :
        ligne = random.randint(0,7)
        colonne = random.randint(0,7)
                
        for boule in ENTOURAGE_BOULES[ligne][colonne] :
            if boule in boules_sur_plateau(statut_boules) :
                if statut_boules[ligne][colonne] == False :
                    couleurs_boules[ligne][colonne] = couleur
                    check_boules(couleurs_boules,ligne,colonne,couleur)
                    statut_boules[ligne][colonne] = True
                    return

def dessiner_forme(index,x,y,rayon,couleur) :
    """
    Dessiner une forme sur le plateau ( boule par defaut )
    : param index: index de la forme ( cercle , rectangle , triangle , etoile )
    : param x: abscisse du centre
    : param y: ordonnee du centre
    : param rayon: rayon en pixels
    : param couleur: couleur de la forme
    
    : return (list): liste des composants de la forme
    """
    long_cote_rec = taille_fenetre*0.031
    long_cote_tri = taille_fenetre*0.072
    long_cote_eto = taille_fenetre*0.080
    
    if index == 0 :
        if couleur == 'non' :
            couleur1 = '#3C3B40'
            couleur2 = '#5F5C73'
            couleur3 = '#7D7C8E'
            couleur4 = '#B7B4C7'
            
        if couleur == 'red' :
            couleur1 = '#B90F12'
            couleur2 = '#E61D24'
            couleur3 = '#EE4A4B'
            couleur4 = '#F36C69'
            
        if couleur == 'orange' :
            couleur1 = '#CC5D15'
            couleur2 = '#E97818'
            couleur3 = '#F59B5C'
            couleur4 = '#F8BB8E'
            
        if couleur == 'yellow' :
            couleur1 = '#F2A81D'
            couleur2 = '#FAE202'
            couleur3 = '#F8E666'
            couleur4 = '#FDF899'
      
        if couleur == 'blue' :
            couleur1 = '#055A99'
            couleur2 = '#0083C4'
            couleur3 = '#3C9CCE'
            couleur4 = '#6BB0D9'
            
        if couleur == 'indigo' :
            couleur1 = '#551CA6'
            couleur2 = '#762CBF'
            couleur3 = '#934ED9'
            couleur4 = '#B16BF0'
            
        if couleur == 'pink' :
            couleur1 = '#CE2290'
            couleur2 = '#F249C5'
            couleur3 = '#F86DD0'
            couleur4 = '#FA98E0'
            
        if couleur == 'green' :
            couleur1 = '#226A21'
            couleur2 = '#308D2F'
            couleur3 = '#369E35'
            couleur4 = '#58C158'
        
        if couleur == None :
            return

        return [fltk.cercle(x,y,rayon,couleur1,couleur1),
                fltk.cercle(x,y-rayon/20,rayon/1.1,couleur2,couleur2),
                fltk.cercle(x-rayon/6,y-rayon/5,rayon/1.8,couleur3,couleur3),
                fltk.cercle(x-rayon/12,y-rayon/2.8,rayon/4,couleur4,couleur4),
                fltk.cercle(x-rayon/2.5,y-rayon/20,rayon/7,couleur4,couleur4)]

    if index == 1 :
        if couleur == 'non' :
            couleur1 = '#3C3B40'
            couleur2 = '#5F5C73'
            couleur3 = '#7D7C8E'
            couleur4 = '#B7B4C7'
            
        if couleur == 'red' :
            couleur1 = '#B90F12'
            couleur2 = '#E61D24'
            couleur3 = '#EE4A4B'
            couleur4 = '#F36C69'
            
        if couleur == 'orange' :
            couleur1 = '#CC5D15'
            couleur2 = '#E97818'
            couleur3 = '#F59B5C'
            couleur4 = '#F8BB8E'
            
        if couleur == 'yellow' :
            couleur1 = '#F2A81D'
            couleur2 = '#FAE202'
            couleur3 = '#F8E666'
            couleur4 = '#FDF899'
      
        if couleur == 'blue' :
            couleur1 = '#055A99'
            couleur2 = '#0083C4'
            couleur3 = '#3C9CCE'
            couleur4 = '#6BB0D9'
            
        if couleur == 'indigo' :
            couleur1 = '#551CA6'
            couleur2 = '#762CBF'
            couleur3 = '#934ED9'
            couleur4 = '#B16BF0'
            
        if couleur == 'pink' :
            couleur1 = '#CE2290'
            couleur2 = '#F249C5'
            couleur3 = '#F86DD0'
            couleur4 = '#FA98E0'
            
        if couleur == 'green' :
            couleur1 = '#226A21'
            couleur2 = '#308D2F'
            couleur3 = '#369E35'
            couleur4 = '#58C158'
        
        if couleur == None :
            return
        
        return [fltk.rectangle(x-long_cote_rec,y-long_cote_rec,x+long_cote_rec,y+long_cote_rec,'black',couleur1),
                fltk.rectangle(x-long_cote_rec*7/8,y-long_cote_rec*7/8,x+long_cote_rec*7/8,y+long_cote_rec*7/8,couleur2,couleur2),
                fltk.cercle(x+long_cote_rec*1/56,y-long_cote_rec*1/46,long_cote_rec*3/5,couleur3,couleur3),
                fltk.cercle(x+long_cote_rec*1/10,y-long_cote_rec*1/7,long_cote_rec*3/12,couleur4,couleur4),
                fltk.cercle(x-long_cote_rec*1/6,y+long_cote_rec*1/5,long_cote_rec*3/26,couleur4,couleur4)]

    if index == 2 :
        if couleur == 'non' :
            couleur1 = '#3C3B40'
            couleur2 = '#5F5C73'
            couleur3 = '#7D7C8E'
            couleur4 = '#B7B4C7'
            
        if couleur == 'red' :
            couleur1 = '#B90F12'
            couleur2 = '#E61D24'
            couleur3 = '#EE4A4B'
            couleur4 = '#F36C69'
            
        if couleur == 'orange' :
            couleur1 = '#CC5D15'
            couleur2 = '#E97818'
            couleur3 = '#F59B5C'
            couleur4 = '#F8BB8E'
            
        if couleur == 'yellow' :
            couleur1 = '#F2A81D'
            couleur2 = '#FAE202'
            couleur3 = '#F8E666'
            couleur4 = '#FDF899'
      
        if couleur == 'blue' :
            couleur1 = '#055A99'
            couleur2 = '#0083C4'
            couleur3 = '#3C9CCE'
            couleur4 = '#6BB0D9'
            
        if couleur == 'indigo' :
            couleur1 = '#551CA6'
            couleur2 = '#762CBF'
            couleur3 = '#934ED9'
            couleur4 = '#B16BF0'
            
        if couleur == 'pink' :
            couleur1 = '#CE2290'
            couleur2 = '#F249C5'
            couleur3 = '#F86DD0'
            couleur4 = '#FA98E0'
            
        if couleur == 'green' :
            couleur1 = '#226A21'
            couleur2 = '#308D2F'
            couleur3 = '#369E35'
            couleur4 = '#58C158'
        
        if couleur == None :
            return
        
        tri = [(x,y-long_cote_tri*1/1.68),(x+long_cote_tri*48/100,y+long_cote_tri*34/100),(x-long_cote_tri*48/100,y+long_cote_tri*34/100)]
        tri1 = [(x,y-long_cote_tri*1/1.96),(x+long_cote_tri*42/100,y+long_cote_tri*30/100),(x-long_cote_tri*42/100,y+long_cote_tri*30/100)]
        tri2 = [(x,y-long_cote_tri*1/3),(x+long_cote_tri*24/100,y+long_cote_tri*16/100),(x-long_cote_tri*24/100,y+long_cote_tri*16/100)]
        
        return [fltk.polygone(tri,'black',couleur1),
                fltk.polygone(tri1,couleur2,couleur2),
                fltk.polygone(tri2,couleur3,couleur3),
                fltk.cercle(x+long_cote_tri*1/78,y-long_cote_tri*1/10,long_cote_tri*7/100,couleur4,couleur4),
                fltk.cercle(x-long_cote_tri*1/16,y+long_cote_tri*1/30,long_cote_tri*4/100,couleur4,couleur4)]
    
    if index == 3 :
        if couleur == 'non' :
            couleur1 = '#3C3B40'
            couleur2 = '#5F5C73'
            couleur3 = '#7D7C8E'
            couleur4 = '#B7B4C7'
            
        if couleur == 'red' :
            couleur1 = '#B90F12'
            couleur2 = '#E61D24'
            couleur3 = '#EE4A4B'
            couleur4 = '#F36C69'
            
        if couleur == 'orange' :
            couleur1 = '#CC5D15'
            couleur2 = '#E97818'
            couleur3 = '#F59B5C'
            couleur4 = '#F8BB8E'
            
        if couleur == 'yellow' :
            couleur1 = '#F2A81D'
            couleur2 = '#FAE202'
            couleur3 = '#F8E666'
            couleur4 = '#FDF899'
      
        if couleur == 'blue' :
            couleur1 = '#055A99'
            couleur2 = '#0083C4'
            couleur3 = '#3C9CCE'
            couleur4 = '#6BB0D9'
            
        if couleur == 'indigo' :
            couleur1 = '#551CA6'
            couleur2 = '#762CBF'
            couleur3 = '#934ED9'
            couleur4 = '#B16BF0'
            
        if couleur == 'pink' :
            couleur1 = '#CE2290'
            couleur2 = '#F249C5'
            couleur3 = '#F86DD0'
            couleur4 = '#FA98E0'
            
        if couleur == 'green' :
            couleur1 = '#226A21'
            couleur2 = '#308D2F'
            couleur3 = '#369E35'
            couleur4 = '#58C158'
        
        if couleur == None :
            return

        star = [(x,y+long_cote_eto*0.25),(x+long_cote_eto*0.25,y+long_cote_eto*0.5),(x+long_cote_eto*0.15,y+long_cote_eto*0.12),(x+long_cote_eto*0.5,y-long_cote_eto*0.04),(x+long_cote_eto*0.08,y-long_cote_eto*0.04),(x,y-long_cote_eto*0.4),(x-long_cote_eto*0.08,y-long_cote_eto*0.04),(x-long_cote_eto*0.5,y-long_cote_eto*0.04),(x-long_cote_eto*0.15,y+long_cote_eto*0.12),(x-long_cote_eto*0.25,y+long_cote_eto*0.5)]
        star1 = [(x,y+long_cote_eto*0.2),(x+long_cote_eto*0.2,y+long_cote_eto*0.41),(x+long_cote_eto*0.11,y+long_cote_eto*0.1),(x+long_cote_eto*0.4,y-long_cote_eto*0.02),(x+long_cote_eto*0.06,y-long_cote_eto*0.02),(x,y-long_cote_eto*0.31),(x-long_cote_eto*0.06,y-long_cote_eto*0.02),(x-long_cote_eto*0.4,y-long_cote_eto*0.02),(x-long_cote_eto*0.11,y+long_cote_eto*0.1),(x-long_cote_eto*0.2,y+long_cote_eto*0.41)]
        star2 = [(x,y+long_cote_eto*0.2),(x+long_cote_eto*0.11,y+long_cote_eto*0.1),(x+long_cote_eto*0.06,y-long_cote_eto*0.02),(x-long_cote_eto*0.06,y-long_cote_eto*0.02),(x-long_cote_eto*0.11,y+long_cote_eto*0.1)]

        return [fltk.polygone(star,couleur1,couleur1),
                fltk.polygone(star1,couleur2,couleur2),
                fltk.polygone(star2,couleur3,couleur3),
                fltk.cercle(x-long_cote_eto*0.04,y+long_cote_eto*0.11,long_cote_eto*0.015,couleur4,couleur4),
                fltk.cercle(x+long_cote_eto*0.01,y+long_cote_eto*0.04,long_cote_eto*0.04,couleur4,couleur4),
                fltk.cercle(x,y+long_cote_eto*0.12,long_cote_eto*0.014,couleur4,couleur4)]

def dessiner_boules_cote(info_partie,couleur_exterieure) :
    """
    Dessiner les boules sur les cotes du plateau
    tel que chaque cote represente un joueur avec sa couleur
    """
    nombre_joueurs = info_partie["nombre_joueurs"]
    couleurs_joueurs = info_partie["couleurs_joueurs"]
    
    couleurs = copy.deepcopy(couleurs_joueurs)
    
    for idx,couleur in enumerate(couleurs) :
        if couleur == 'non' :
            couleurs[idx] = '#5F5C73'
            
        if couleur == 'red' :
            couleurs[idx] = '#E61D24'
            
        if couleur == 'orange' :
            couleurs[idx] = '#E97818'
            
        if couleur == 'yellow' :
            couleurs[idx] = '#FAE202'
      
        if couleur == 'blue' :
            couleurs[idx] = '#0083C4'
            
        if couleur == 'indigo' :
            couleurs[idx] = '#762CBF'
            
        if couleur == 'pink' :
            couleurs[idx] = '#F249C5'
            
        if couleur == 'green' :
            couleurs[idx] = '#308D2F'
    
    fltk.cercle(taille_fenetre*0.500,taille_fenetre*0.155,taille_fenetre*0.016,couleur_exterieure,'gray',taille_fenetre*0.001)
    fltk.cercle(taille_fenetre*0.400,taille_fenetre*0.155,taille_fenetre*0.008,couleur_exterieure,'gray',taille_fenetre*0.001)
    fltk.cercle(taille_fenetre*0.600,taille_fenetre*0.155,taille_fenetre*0.008,couleur_exterieure,'gray',taille_fenetre*0.001)
    
    fltk.cercle(taille_fenetre*0.945,taille_fenetre*0.600,taille_fenetre*0.016,couleur_exterieure,'gray',taille_fenetre*0.001)
    fltk.cercle(taille_fenetre*0.945,taille_fenetre*0.500,taille_fenetre*0.008,couleur_exterieure,'gray',taille_fenetre*0.001)
    fltk.cercle(taille_fenetre*0.945,taille_fenetre*0.700,taille_fenetre*0.008,couleur_exterieure,'gray',taille_fenetre*0.001)
    
    fltk.cercle(taille_fenetre*0.500,taille_fenetre*1.045,taille_fenetre*0.016,couleur_exterieure,'gray',taille_fenetre*0.001)
    fltk.cercle(taille_fenetre*0.400,taille_fenetre*1.045,taille_fenetre*0.008,couleur_exterieure,'gray',taille_fenetre*0.001)
    fltk.cercle(taille_fenetre*0.600,taille_fenetre*1.045,taille_fenetre*0.008,couleur_exterieure,'gray',taille_fenetre*0.001)
    
    fltk.cercle(taille_fenetre*0.055,taille_fenetre*0.600,taille_fenetre*0.016,couleur_exterieure,'gray',taille_fenetre*0.001)
    fltk.cercle(taille_fenetre*0.055,taille_fenetre*0.500,taille_fenetre*0.008,couleur_exterieure,'gray',taille_fenetre*0.001)
    fltk.cercle(taille_fenetre*0.055,taille_fenetre*0.700,taille_fenetre*0.008,couleur_exterieure,'gray',taille_fenetre*0.001)
     
    if nombre_joueurs == 4 :
        fltk.cercle(CORDONNE_CENTRE_BOULES_COTES[0][0],CORDONNE_CENTRE_BOULES_COTES[0][1],taille_fenetre*0.018,couleur_exterieure,couleurs[0],taille_fenetre*0.001)
        fltk.cercle(CORDONNE_CENTRE_BOULES_COTES[1][0],CORDONNE_CENTRE_BOULES_COTES[1][1],taille_fenetre*0.018,couleur_exterieure,couleurs[1],taille_fenetre*0.001)
        fltk.cercle(CORDONNE_CENTRE_BOULES_COTES[2][0],CORDONNE_CENTRE_BOULES_COTES[2][1],taille_fenetre*0.018,couleur_exterieure,couleurs[2],taille_fenetre*0.001)
        fltk.cercle(CORDONNE_CENTRE_BOULES_COTES[3][0],CORDONNE_CENTRE_BOULES_COTES[3][1],taille_fenetre*0.018,couleur_exterieure,couleurs[3],taille_fenetre*0.001)
        
    elif nombre_joueurs == 3 :
        fltk.cercle(CORDONNE_CENTRE_BOULES_COTES[0][0],CORDONNE_CENTRE_BOULES_COTES[0][1],taille_fenetre*0.018,couleur_exterieure,couleurs[0],taille_fenetre*0.001)
        fltk.cercle(CORDONNE_CENTRE_BOULES_COTES[1][0],CORDONNE_CENTRE_BOULES_COTES[1][1],taille_fenetre*0.018,couleur_exterieure,couleurs[1],taille_fenetre*0.001)
        fltk.cercle(CORDONNE_CENTRE_BOULES_COTES[2][0],CORDONNE_CENTRE_BOULES_COTES[2][1],taille_fenetre*0.018,couleur_exterieure,couleurs[2],taille_fenetre*0.001)
        
    elif nombre_joueurs in [1,2] :
        fltk.cercle(CORDONNE_CENTRE_BOULES_COTES[0][0],CORDONNE_CENTRE_BOULES_COTES[0][1],taille_fenetre*0.018,couleur_exterieure,couleurs[0],taille_fenetre*0.001)
        fltk.cercle(CORDONNE_CENTRE_BOULES_COTES[1][0],CORDONNE_CENTRE_BOULES_COTES[1][1],taille_fenetre*0.018,couleur_exterieure,couleurs[1],taille_fenetre*0.001)

def boules_indiquer_tour_joueur(info_partie) :
    """
    Indiquer le tour d'un joueur en dessinant des formes contourees en blanc
    """
    nombre_joueurs = info_partie["nombre_joueurs"]
    couleurs = copy.deepcopy(info_partie["couleurs_joueurs"])
    index_couleur = info_partie["index_couleur"]
    
    for idx,couleur in enumerate(couleurs) :
        if couleur == 'non' :
            couleurs[idx] = '#5F5C73'
            
        if couleur == 'red' :
            couleurs[idx] = '#E61D24'
            
        if couleur == 'orange' :
            couleurs[idx] = '#E97818'
            
        if couleur == 'yellow' :
            couleurs[idx] = '#FAE202'
      
        if couleur == 'blue' :
            couleurs[idx] = '#0083C4'
            
        if couleur == 'indigo' :
            couleurs[idx] = '#762CBF'
            
        if couleur == 'pink' :
            couleurs[idx] = '#F249C5'
            
        if couleur == 'green' :
            couleurs[idx] = '#308D2F'

    if  nombre_joueurs == 4 or nombre_joueurs == 3 :
        if index_couleur == 1 :
            index_joueur = 0
            couleur_cote = couleurs[index_joueur]
            boule_cote_x = CORDONNE_CENTRE_BOULES_COTES[0][0]
            boule_cote_y = CORDONNE_CENTRE_BOULES_COTES[0][1]
            
        elif index_couleur == 2 :
            index_joueur = 1
            couleur_cote = couleurs[index_joueur]
            boule_cote_x = CORDONNE_CENTRE_BOULES_COTES[1][0]
            boule_cote_y = CORDONNE_CENTRE_BOULES_COTES[1][1]
            
        elif index_couleur == 3 :
            index_joueur = 2
            couleur_cote = couleurs[index_joueur]
            boule_cote_x = CORDONNE_CENTRE_BOULES_COTES[2][0]
            boule_cote_y = CORDONNE_CENTRE_BOULES_COTES[2][1]
            
        elif index_couleur == 4 :
            index_joueur = 3
            couleur_cote = couleurs[index_joueur]
            boule_cote_x = CORDONNE_CENTRE_BOULES_COTES[3][0]
            boule_cote_y = CORDONNE_CENTRE_BOULES_COTES[3][1]
            
    if  nombre_joueurs in [1,2] :
        if index_couleur == 1 :
            index_joueur = 0
            couleur_cote = couleurs[index_joueur]
            boule_cote_x = CORDONNE_CENTRE_BOULES_COTES[0][0]
            boule_cote_y = CORDONNE_CENTRE_BOULES_COTES[0][1]
            
        elif index_couleur == 2 :
            index_joueur = 1
            couleur_cote = couleurs[index_joueur]
            boule_cote_x = CORDONNE_CENTRE_BOULES_COTES[1][0]
            boule_cote_y = CORDONNE_CENTRE_BOULES_COTES[1][1]
        
    boule_cote_mini_x1 = CORDONNE_CENTRE_MINI_BOULES_DE_COTES[index_joueur][0][0]
    boule_cote_mini_y1 = CORDONNE_CENTRE_MINI_BOULES_DE_COTES[index_joueur][0][1]
    boule_cote_mini_x2 = CORDONNE_CENTRE_MINI_BOULES_DE_COTES[index_joueur][1][0]
    boule_cote_mini_y2 = CORDONNE_CENTRE_MINI_BOULES_DE_COTES[index_joueur][1][1]
        
    return fltk.cercle(boule_cote_x,boule_cote_y,taille_fenetre*0.018,'white',None,taille_fenetre*0.003), fltk.cercle(boule_cote_mini_x1,boule_cote_mini_y1,taille_fenetre*0.009,'white',couleur_cote,taille_fenetre*0.002), fltk.cercle(boule_cote_mini_x2,boule_cote_mini_y2,taille_fenetre*0.009,'white',couleur_cote,taille_fenetre*0.002)

def dessiner_interieure_trou(x,y,rayon,mode) :
    """
    Dessiner des champs vides ( trous de plateau )
    : param x: abscisse
    : param y: ordonnee
    : param rayon: rayon en pixels
    : param mode: mode du plateau ( configuration )
    """
    if mode == 0 :
        couleur1 = '#000000'
        couleur2 = '#151515'
        couleur3 = '#262626'
    if mode == 1 :
        couleur1 = '#757575'
        couleur2 = '#858585'
        couleur3 = '#AAAAAA'
    if mode == 2 :
        couleur1 = '#101010'
        couleur2 = '#252525'
        couleur3 = '#363636'
    if mode == 3 :
        couleur1 = '#101010'
        couleur2 = '#252525'
        couleur3 = '#363636'
        
    fltk.cercle(x,y,rayon,'black',couleur1)  
    fltk.cercle(x-5,y-1,rayon-15,couleur2,couleur2)
    fltk.cercle(x-7,y+2,rayon/6,couleur3,couleur3)
    
def check_boules(couleurs_boules,ligne,colonne,couleur) :
    """
    Verifier la presence d'une boule de la meme couleur dans les huit directions
    (horizontale, verticale et diagonale)
    et dessine des boules de la même couleur entre la boule
    et la boule la plus proche dans ces directions ( blocage ).
    
    : param couleurs_boules: ( list ) une liste de listes représentant un plateau provisoire
        portant la couleur de la boule à cet endroit ( str ) et None sinon.
    : param ligne   : ( int ) la ligne dans laquelle se trouve la boule placée.
    : param colonne : ( int ) la colonne dans laquelle se trouve la boule placée.
    : param couleur : ( str ) couleur de la boule placée.

    : return : None
    
    """
    extra_droite = extra_gauche = colonne
    extra_haut = extra_bas  = ligne
    extra_haut_droite = extra_bas_droite = extra_haut_gauche = extra_bas_gauche = 0
    
    # Verification :
    for a_droite in range(colonne+1,7+1,1) :
        if couleurs_boules[ligne][a_droite] == None :
            break
        if couleurs_boules[ligne][a_droite] == couleur :
            extra_droite = a_droite
            break

    for a_gauche in range(colonne-1,-1,-1) :
        if couleurs_boules[ligne][a_gauche] == None :
            break
        if couleurs_boules[ligne][a_gauche] == couleur :
            extra_gauche = a_gauche
            break
    
    for a_haut in range(ligne-1,-1,-1) :
        if couleurs_boules[a_haut][colonne] == None :
            break
        if couleurs_boules[a_haut][colonne] == couleur :
            extra_haut = a_haut
            break

    for a_bas  in range(ligne+1,7+1,1) :
        if couleurs_boules[a_bas][colonne] == None :
            break
        if couleurs_boules[a_bas][colonne] == couleur :
            extra_bas = a_bas
            break

    for i in range(1,8) :
        if -1 <= colonne-i <= 7 and -1 <= ligne-i <= 7 :
            if couleurs_boules[ligne-i][colonne-i] == None :
                break
            if couleurs_boules[ligne-i][colonne-i] == couleur :
                extra_haut_gauche = i
                break

    for i in range(1,8) :
        if -1 <= colonne+i <= 7 and -1 <= ligne+i <= 7 :
            if couleurs_boules[ligne+i][colonne+i] == None :
                break
            if couleurs_boules[ligne+i][colonne+i] == couleur :
                extra_bas_droite = i
                break

    for i in range(1,8) :
        if -1 <= colonne+i <= 7 and -1 <= ligne-i <= 7 :
            if couleurs_boules[ligne-i][colonne+i] == None :
                break
            if couleurs_boules[ligne-i][colonne+i] == couleur :
                extra_haut_droite = i
                break

    for i in range(1,8) :
        if -1 <= colonne-i <= 7 and -1 <= ligne+i <= 7 :
            if couleurs_boules[ligne+i][colonne-i] == None :
                break
            if couleurs_boules[ligne+i][colonne-i] == couleur :
                extra_bas_gauche = i
                break

    for boule_horizontal in range(extra_gauche+1,extra_droite) :
        couleurs_boules[ligne][boule_horizontal] = couleur

    for boule_vertical in range(extra_haut+1,extra_bas) :
        couleurs_boules[boule_vertical][colonne] = couleur

    for boule_diagonal in range(1,extra_haut_gauche) :
        couleurs_boules[ligne-boule_diagonal][colonne-boule_diagonal] = couleur

    for boule_diagonal in range(1,extra_bas_droite) :
        couleurs_boules[ligne+boule_diagonal][colonne+boule_diagonal] = couleur

    for boule_diagonal in range(1,extra_haut_droite) :
        couleurs_boules[ligne-boule_diagonal][colonne+boule_diagonal] = couleur

    for boule_diagonal in range(1,extra_bas_gauche) :
        couleurs_boules[ligne+boule_diagonal][colonne-boule_diagonal] = couleur

def dessiner_plateau_mode_nuit() :
    """
    Dessiner un arriere plan contenant un nombre aléatoire
    de points blancs placés aléatoirement si le mode nuit est actif
    
    : 0 param
    : return : None
    """
    for i in range(random.randint(200,400)) :
        fltk.cercle(random.uniform(taille_fenetre*0.080,taille_fenetre*0.920),random.uniform(taille_fenetre*0.180,taille_fenetre*1.020),taille_fenetre*0.001,'white','white')

def charger_plateau_jeu(mode, info) :
    """
    Dessiner le plateau du jeu
    avce les couleurs appropriees au mode selectionne ( param mode ),
    puis dessine le plateau avec ses parties ( le grand disque et la plaque avec les 64 trous ).
    
    : param mode: ( int ) mode du plateau
        mode 0 : plateau gris foncé
        mode 1 : plateau gris clair
        mode 2 : plateau or
        mode 3 : plateau noir avec des points blancs ( mode nuit )
    
    : return : None
    """
    nombre_joueurs = info["nombre_joueurs"]
    noms_joueurs = info["noms_joueurs"]
    couleurs_joueurs = info["couleurs_joueurs"]
    couleurs_boules = info["couleurs_boules"]
    
    if configuration["theme_interface"] == 1 :
        fltk.rectangle(0,0,taille_fenetre,hauteur_fenetre,'#010014','#010014')
        couleur_interieure_ui = 'black'
        couleur_exterieure_ui = 'white'
    elif configuration["theme_interface"] == 0 :
        fltk.rectangle(0,0,taille_fenetre,hauteur_fenetre,'#F1E3A4','#F1E3A4')
        couleur_interieure_ui = 'white'
        couleur_exterieure_ui = 'black'

    if mode == 0 :
        couleur_interieure_plateau = '#828282'
        couleur_interieure_cercle = '#787878'
        couleur_interieure_trou = '#707070'
        couleur_exterieure_plateau = 'black'
        couleur_exterieure_cercle = 'black'
        couleur_exterieure_trou = 'black'
    if mode == 1 :
        couleur_interieure_plateau = '#BFBFBF'
        couleur_interieure_cercle = '#BEBEBE'
        couleur_interieure_trou = '#BBBBBB'
        couleur_exterieure_plateau = 'black'
        couleur_exterieure_cercle = 'black'
        couleur_exterieure_trou = 'black'
    if mode == 2 :
        couleur_interieure_plateau = '#F1C40F'
        couleur_interieure_cercle = '#F4D03F'
        couleur_interieure_trou = 'black'
        couleur_exterieure_plateau = 'white'
        couleur_exterieure_cercle = 'white'
        couleur_exterieure_trou = 'white'
    if mode == 3 :
        couleur_interieure_plateau = 'black'
        couleur_interieure_cercle = 'black'
        couleur_interieure_trou = 'black'
        couleur_exterieure_plateau = 'white'
        couleur_exterieure_cercle = 'white'
        couleur_exterieure_trou = 'white'
    
    #PLATEAU
    fltk.cercle(taille_fenetre*0.500,taille_fenetre*0.600,taille_fenetre*0.470,couleur_exterieure_cercle,couleur_interieure_cercle,taille_fenetre*0.001)
    fltk.polygone(PLATEAU,couleur_exterieure_plateau,couleur_interieure_plateau)
    dessiner_boules_cote(info,couleur_exterieure_trou)
    
    #BUTTON PAUSE
    fltk.cercle(taille_fenetre*0.035,taille_fenetre*0.035,taille_fenetre*0.025,couleur_exterieure_ui,couleur_interieure_ui,taille_fenetre*0.001)
    fltk.rectangle(taille_fenetre*0.025,taille_fenetre*0.025,taille_fenetre*0.0325,taille_fenetre*0.045,couleur_exterieure_ui,couleur_exterieure_ui,taille_fenetre*0.001)
    fltk.rectangle(taille_fenetre*0.0375,taille_fenetre*0.025,taille_fenetre*0.045,taille_fenetre*0.045,couleur_exterieure_ui,couleur_exterieure_ui,taille_fenetre*0.001)

    if mode == 3 :
        dessiner_plateau_mode_nuit()

    y_depart = taille_fenetre*0.2325
    for i in range(8) :
        x_depart = taille_fenetre*0.1325
        for j in range(8) :
            fltk.cercle(x_depart,y_depart,taille_fenetre*0.048,couleur_exterieure_trou,couleur_interieure_trou)
            dessiner_interieure_trou(x_depart,y_depart,taille_fenetre*0.040,mode)
            x_depart += taille_fenetre*0.105

        y_depart += taille_fenetre*0.105
    
    for i in range(8) :
        for j in range(8) :
            dessiner_forme(configuration["mode_boules"],CORDONNE_CENTRE_BOULES[i][j][0],CORDONNE_CENTRE_BOULES[i][j][1],taille_fenetre*0.036,couleurs_boules[i][j])

def menu_pause() :
    """
    Afficher un menu de pause
    un button pour quitter et un button pour reprendre le jeu
    : 0 param
    : return (str): decision "jouer","quitter","menu"
    """
    if configuration["theme_interface"] == 1 :
        couleur_interne = 'black'
        couleur_bordure = 'white'
        couleur_externe = '#010014'
        couleur_texte = 'white'
    if configuration["theme_interface"] == 0 :
        couleur_interne = 'white'
        couleur_bordure = 'black'
        couleur_externe = '#F1E3A4'
        couleur_texte = 'black'

    menu_pause =    [fltk.rectangle(taille_fenetre*0.250,taille_fenetre*0.300,taille_fenetre*0.750,taille_fenetre*0.700,couleur_bordure,couleur_externe)
                    ,fltk.texte(taille_fenetre*0.500,taille_fenetre*0.350,IU_TEXTE['menu_pause_pause'][configuration["index_langue"]], couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.024))
                    ,fltk.rectangle(taille_fenetre*0.300,taille_fenetre*0.400,taille_fenetre*0.700,taille_fenetre*0.500,couleur_bordure,couleur_interne)
                    ,fltk.texte(taille_fenetre*0.500,taille_fenetre*0.450,IU_TEXTE['menu_pause_reprendre'][configuration["index_langue"]], couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.016))
                    ,fltk.rectangle(taille_fenetre*0.300,taille_fenetre*0.550,taille_fenetre*0.700,taille_fenetre*0.650,couleur_bordure,couleur_interne)
                    ,fltk.texte(taille_fenetre*0.500,taille_fenetre*0.600,IU_TEXTE['menu_pause_sauvquit'][configuration["index_langue"]], couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.016))]
    
    while True :
        ev_pause = fltk.attend_ev()
        type_ev_p = fltk.type_ev(ev_pause)
        
        if type_ev_p == "Quitte" :
            efface_multiple_objets(menu_pause)
            return "quitter"
        elif type_ev_p == "ClicGauche" :
            if taille_fenetre*0.300 <= fltk.abscisse_souris() <= taille_fenetre*0.700 :
                if taille_fenetre*0.400 <= fltk.ordonnee_souris() <= taille_fenetre*0.500 :
                    efface_multiple_objets(menu_pause)
                    return "jouer"
                elif taille_fenetre*0.550 <= fltk.ordonnee_souris() <= taille_fenetre*0.650 :
                    efface_multiple_objets(menu_pause)
                    return "menu"
    
def menu_fin_manche(info) :
    """
    Afficher un menu a la fin de chaque manche
    indiquant le score de chaque joueur, le gagnant,
    un button pour quitter et un button pour commencer la manche suivante
    : param info: (dict) informations sur la partie
    : return (str): decision "jouer","quitter","menu"
    """
    couleurs_cercles_menu_fin = []
    
    for couleur in info['couleurs_joueurs'] :
        if couleur == 'red' :
            couleurs_cercles_menu_fin.append('#E61D24')
        if couleur == 'orange' :
            couleurs_cercles_menu_fin.append('#E97818')
        if couleur == 'yellow' :
            couleurs_cercles_menu_fin.append('#FAE202')
        if couleur == 'blue' :
            couleurs_cercles_menu_fin.append('#0083C4')
        if couleur == 'indigo' :
            couleurs_cercles_menu_fin.append('#762CBF')
        if couleur == 'pink' :
            couleurs_cercles_menu_fin.append('#F249C5')
        if couleur == 'green' :
            couleurs_cercles_menu_fin.append('#308D2F')
    
    if configuration["theme_interface"] == 1 :
        couleur_interne = 'black'
        couleur_bordure = 'white'
        couleur_externe = '#010014'
        couleur_texte = 'white'
    if configuration["theme_interface"] == 0 :
        couleur_interne = 'white'
        couleur_bordure = 'black'
        couleur_externe = '#F1E3A4'
        couleur_texte = 'black'

    menu_fin_manche =   [fltk.rectangle(taille_fenetre*0.150,taille_fenetre*0.200,taille_fenetre*0.850,taille_fenetre*0.850,couleur_bordure,couleur_externe)
                        ,fltk.texte(taille_fenetre*0.500,taille_fenetre*0.250,IU_TEXTE['menu_fin_manche_fini'][configuration["index_langue"]], couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.030))
                        ,fltk.texte(taille_fenetre*0.500,taille_fenetre*0.450,IU_TEXTE['menu_fin_manche_scores'][configuration["index_langue"]], couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.020))
                        ,fltk.rectangle(taille_fenetre*0.5125,taille_fenetre*0.725,taille_fenetre*0.825,taille_fenetre*0.825,couleur_bordure,couleur_interne)
                        ,fltk.texte(taille_fenetre*0.66875,taille_fenetre*0.775,IU_TEXTE['menu_fin_manche_suivant'][configuration["index_langue"]], couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.016))
                        ,fltk.rectangle(taille_fenetre*0.175,taille_fenetre*0.725,taille_fenetre*0.4875,taille_fenetre*0.825,couleur_bordure,couleur_interne)
                        ,fltk.texte(taille_fenetre*0.33125,taille_fenetre*0.775,IU_TEXTE['menu_fin_manche_quitter'][configuration["index_langue"]], couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.016))]
    
    if len(info["score_manche"]) == 4 :
        menu_fin_manche.append(fltk.texte(taille_fenetre*0.300,taille_fenetre*0.500,f'{info["noms_joueurs"][0]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))
        menu_fin_manche.append(fltk.texte(taille_fenetre*0.425,taille_fenetre*0.500,f'{info["noms_joueurs"][1]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))
        menu_fin_manche.append(fltk.texte(taille_fenetre*0.550,taille_fenetre*0.500,f'{info["noms_joueurs"][2]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))
        menu_fin_manche.append(fltk.texte(taille_fenetre*0.675,taille_fenetre*0.500,f'{info["noms_joueurs"][3]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))
    
        menu_fin_manche.append(fltk.texte(taille_fenetre*0.300,taille_fenetre*0.545,f'{info["score_manche"][0]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))
        menu_fin_manche.append(fltk.texte(taille_fenetre*0.425,taille_fenetre*0.545,f'{info["score_manche"][1]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))
        menu_fin_manche.append(fltk.texte(taille_fenetre*0.550,taille_fenetre*0.545,f'{info["score_manche"][2]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))
        menu_fin_manche.append(fltk.texte(taille_fenetre*0.675,taille_fenetre*0.545,f'{info["score_manche"][3]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))
    
        menu_fin_manche.append(fltk.cercle(taille_fenetre*0.300,taille_fenetre*0.600, taille_fenetre*0.015, couleur_texte, couleurs_cercles_menu_fin[0], int(taille_fenetre*0.002)))
        menu_fin_manche.append(fltk.cercle(taille_fenetre*0.425,taille_fenetre*0.600, taille_fenetre*0.015, couleur_texte, couleurs_cercles_menu_fin[1], int(taille_fenetre*0.002)))
        menu_fin_manche.append(fltk.cercle(taille_fenetre*0.550,taille_fenetre*0.600, taille_fenetre*0.015, couleur_texte, couleurs_cercles_menu_fin[2], int(taille_fenetre*0.002)))
        menu_fin_manche.append(fltk.cercle(taille_fenetre*0.675,taille_fenetre*0.600, taille_fenetre*0.015, couleur_texte, couleurs_cercles_menu_fin[3], int(taille_fenetre*0.002)))
    
    if len(info["score_manche"]) == 3 :
        menu_fin_manche.append(fltk.texte(taille_fenetre*0.325,taille_fenetre*0.500,f'{info["noms_joueurs"][0]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))
        menu_fin_manche.append(fltk.texte(taille_fenetre*0.500,taille_fenetre*0.500,f'{info["noms_joueurs"][1]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))
        menu_fin_manche.append(fltk.texte(taille_fenetre*0.675,taille_fenetre*0.500,f'{info["noms_joueurs"][2]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))
    
        menu_fin_manche.append(fltk.texte(taille_fenetre*0.325,taille_fenetre*0.545,f'{info["score_manche"][0]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))
        menu_fin_manche.append(fltk.texte(taille_fenetre*0.500,taille_fenetre*0.545,f'{info["score_manche"][1]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))
        menu_fin_manche.append(fltk.texte(taille_fenetre*0.675,taille_fenetre*0.545,f'{info["score_manche"][2]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))
        
        menu_fin_manche.append(fltk.cercle(taille_fenetre*0.325,taille_fenetre*0.600, taille_fenetre*0.015, couleur_texte, couleurs_cercles_menu_fin[0], int(taille_fenetre*0.002)))
        menu_fin_manche.append(fltk.cercle(taille_fenetre*0.500,taille_fenetre*0.600, taille_fenetre*0.015, couleur_texte, couleurs_cercles_menu_fin[1], int(taille_fenetre*0.002)))
        menu_fin_manche.append(fltk.cercle(taille_fenetre*0.675,taille_fenetre*0.600, taille_fenetre*0.015, couleur_texte, couleurs_cercles_menu_fin[2], int(taille_fenetre*0.002)))
    
    if len(info["score_manche"]) == 2 :
        menu_fin_manche.append(fltk.texte(taille_fenetre*0.350,taille_fenetre*0.500,f'{info["noms_joueurs"][0]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))
        menu_fin_manche.append(fltk.texte(taille_fenetre*0.650,taille_fenetre*0.500,f'{info["noms_joueurs"][1]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))

        menu_fin_manche.append(fltk.texte(taille_fenetre*0.350,taille_fenetre*0.545,f'{info["score_manche"][0]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))
        menu_fin_manche.append(fltk.texte(taille_fenetre*0.650,taille_fenetre*0.545,f'{info["score_manche"][1]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))

        menu_fin_manche.append(fltk.cercle(taille_fenetre*0.350,taille_fenetre*0.600, taille_fenetre*0.015, couleur_texte, couleurs_cercles_menu_fin[0], int(taille_fenetre*0.002)))
        menu_fin_manche.append(fltk.cercle(taille_fenetre*0.650,taille_fenetre*0.600, taille_fenetre*0.015, couleur_texte, couleurs_cercles_menu_fin[1], int(taille_fenetre*0.002)))
        
    menu_fin_manche.append(fltk.texte(taille_fenetre*0.500,taille_fenetre*0.350,f'{IU_TEXTE["menu_fin_manche_gagnant"][configuration["index_langue"]]} : {info["noms_joueurs"][info["score_manche"].index(max(info["score_manche"]))]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.024)))

    while True :
        ev_fin_manche = fltk.attend_ev()
        type_ev_fin_manche = fltk.type_ev(ev_fin_manche)
        
        if type_ev_fin_manche == "Quitte" :
            efface_multiple_objets(menu_fin_manche)
            return "quitter"
        elif type_ev_fin_manche == "ClicGauche" :
            if taille_fenetre*0.725 <= fltk.ordonnee_souris() <= taille_fenetre*0.825 :
                if taille_fenetre*0.175 <= fltk.abscisse_souris() <= taille_fenetre*0.4875 :
                    efface_multiple_objets(menu_fin_manche)
                    return "menu"
                elif taille_fenetre*0.5125 <= fltk.abscisse_souris() <= taille_fenetre*0.825 :
                    efface_multiple_objets(menu_fin_manche)
                    info["nombre_manches"] += 1
                    sauvegarder_jeu(info)
                    return "jouer"

def menu_fin_partie(info) :
    """
    Afficher un menu a la fin de chaque partie
    indiquant le score de chaque joueur, le gagnant,
    un button pour quitter et revenir au menu
    : param info: (dict) informations sur la partie
    : return (str): decision "jouer","quitter","menu"
    """
    couleurs_cercles_menu_fin = []
    
    for couleur in info['couleurs_joueurs'] :
        if couleur == 'red' :
            couleurs_cercles_menu_fin.append('#E61D24')
        if couleur == 'orange' :
            couleurs_cercles_menu_fin.append('#E97818')
        if couleur == 'yellow' :
            couleurs_cercles_menu_fin.append('#FAE202')
        if couleur == 'blue' :
            couleurs_cercles_menu_fin.append('#0083C4')
        if couleur == 'indigo' :
            couleurs_cercles_menu_fin.append('#762CBF')
        if couleur == 'pink' :
            couleurs_cercles_menu_fin.append('#F249C5')
        if couleur == 'green' :
            couleurs_cercles_menu_fin.append('#308D2F')
    
    if configuration["theme_interface"] == 1 :
        couleur_interne = 'black'
        couleur_bordure = 'white'
        couleur_externe = '#010014'
        couleur_texte = 'white'
    if configuration["theme_interface"] == 0 :
        couleur_interne = 'white'
        couleur_bordure = 'black'
        couleur_externe = '#F1E3A4'
        couleur_texte = 'black'

    menu_fin_partie =   [fltk.rectangle(taille_fenetre*0.150,taille_fenetre*0.200,taille_fenetre*0.850,taille_fenetre*0.850,couleur_bordure,couleur_externe)
                        ,fltk.texte(taille_fenetre*0.500,taille_fenetre*0.250,IU_TEXTE['menu_fin_partie_fini'][configuration["index_langue"]], couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.030))
                        ,fltk.texte(taille_fenetre*0.500,taille_fenetre*0.450,IU_TEXTE['menu_fin_manche_scores'][configuration["index_langue"]], couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.020))
                        ,fltk.rectangle(taille_fenetre*0.325,taille_fenetre*0.700,taille_fenetre*0.675,taille_fenetre*0.800,couleur_bordure,couleur_interne)
                        ,fltk.texte(taille_fenetre*0.500,taille_fenetre*0.750,IU_TEXTE['menu_fin_manche_quitter'][configuration["index_langue"]], couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018))]
    
    if len(info["score_total"]) == 4 :
        menu_fin_partie.append(fltk.texte(taille_fenetre*0.300,taille_fenetre*0.500,f'{info["noms_joueurs"][0]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))
        menu_fin_partie.append(fltk.texte(taille_fenetre*0.425,taille_fenetre*0.500,f'{info["noms_joueurs"][1]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))
        menu_fin_partie.append(fltk.texte(taille_fenetre*0.550,taille_fenetre*0.500,f'{info["noms_joueurs"][2]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))
        menu_fin_partie.append(fltk.texte(taille_fenetre*0.675,taille_fenetre*0.500,f'{info["noms_joueurs"][3]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))
    
        menu_fin_partie.append(fltk.texte(taille_fenetre*0.300,taille_fenetre*0.545,f'{info["score_total"][0]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))
        menu_fin_partie.append(fltk.texte(taille_fenetre*0.425,taille_fenetre*0.545,f'{info["score_total"][1]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))
        menu_fin_partie.append(fltk.texte(taille_fenetre*0.550,taille_fenetre*0.545,f'{info["score_total"][2]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))
        menu_fin_partie.append(fltk.texte(taille_fenetre*0.675,taille_fenetre*0.545,f'{info["score_total"][3]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))
    
        menu_fin_partie.append(fltk.cercle(taille_fenetre*0.300,taille_fenetre*0.600, taille_fenetre*0.015, couleur_texte, couleurs_cercles_menu_fin[0], int(taille_fenetre*0.002)))
        menu_fin_partie.append(fltk.cercle(taille_fenetre*0.425,taille_fenetre*0.600, taille_fenetre*0.015, couleur_texte, couleurs_cercles_menu_fin[1], int(taille_fenetre*0.002)))
        menu_fin_partie.append(fltk.cercle(taille_fenetre*0.550,taille_fenetre*0.600, taille_fenetre*0.015, couleur_texte, couleurs_cercles_menu_fin[2], int(taille_fenetre*0.002)))
        menu_fin_partie.append(fltk.cercle(taille_fenetre*0.675,taille_fenetre*0.600, taille_fenetre*0.015, couleur_texte, couleurs_cercles_menu_fin[3], int(taille_fenetre*0.002)))
    
    if len(info["score_total"]) == 3 :
        menu_fin_partie.append(fltk.texte(taille_fenetre*0.325,taille_fenetre*0.500,f'{info["noms_joueurs"][0]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))
        menu_fin_partie.append(fltk.texte(taille_fenetre*0.500,taille_fenetre*0.500,f'{info["noms_joueurs"][1]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))
        menu_fin_partie.append(fltk.texte(taille_fenetre*0.675,taille_fenetre*0.500,f'{info["noms_joueurs"][2]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))
    
        menu_fin_partie.append(fltk.texte(taille_fenetre*0.325,taille_fenetre*0.545,f'{info["score_total"][0]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))
        menu_fin_partie.append(fltk.texte(taille_fenetre*0.500,taille_fenetre*0.545,f'{info["score_total"][1]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))
        menu_fin_partie.append(fltk.texte(taille_fenetre*0.675,taille_fenetre*0.545,f'{info["score_total"][2]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))
        
        menu_fin_partie.append(fltk.cercle(taille_fenetre*0.325,taille_fenetre*0.600, taille_fenetre*0.015, couleur_texte, couleurs_cercles_menu_fin[0], int(taille_fenetre*0.002)))
        menu_fin_partie.append(fltk.cercle(taille_fenetre*0.500,taille_fenetre*0.600, taille_fenetre*0.015, couleur_texte, couleurs_cercles_menu_fin[1], int(taille_fenetre*0.002)))
        menu_fin_partie.append(fltk.cercle(taille_fenetre*0.675,taille_fenetre*0.600, taille_fenetre*0.015, couleur_texte, couleurs_cercles_menu_fin[2], int(taille_fenetre*0.002)))
    
    if len(info["score_total"]) == 2 :
        menu_fin_partie.append(fltk.texte(taille_fenetre*0.350,taille_fenetre*0.500,f'{info["noms_joueurs"][0]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))
        menu_fin_partie.append(fltk.texte(taille_fenetre*0.650,taille_fenetre*0.500,f'{info["noms_joueurs"][1]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))

        menu_fin_partie.append(fltk.texte(taille_fenetre*0.350,taille_fenetre*0.545,f'{info["score_total"][0]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))
        menu_fin_partie.append(fltk.texte(taille_fenetre*0.650,taille_fenetre*0.545,f'{info["score_total"][1]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.018)))

        menu_fin_partie.append(fltk.cercle(taille_fenetre*0.350,taille_fenetre*0.600, taille_fenetre*0.015, couleur_texte, couleurs_cercles_menu_fin[0], int(taille_fenetre*0.002)))
        menu_fin_partie.append(fltk.cercle(taille_fenetre*0.650,taille_fenetre*0.600, taille_fenetre*0.015, couleur_texte, couleurs_cercles_menu_fin[1], int(taille_fenetre*0.002)))
        
    menu_fin_partie.append(fltk.texte(taille_fenetre*0.500,taille_fenetre*0.350,f'{IU_TEXTE["menu_fin_partie_gagnant"][configuration["index_langue"]]} : {info["noms_joueurs"][info["score_total"].index(max(info["score_total"]))]}', couleur=couleur_texte, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.024)))

    while True :
        ev_fin_partie = fltk.attend_ev()
        type_ev_fin_partie = fltk.type_ev(ev_fin_partie)
        
        if type_ev_fin_partie == "Quitte" :
            efface_multiple_objets(menu_fin_partie)
            return "quitter"
        elif type_ev_fin_partie == "ClicGauche" :
            if taille_fenetre*0.700 <= fltk.ordonnee_souris() <= taille_fenetre*0.800 :
                if taille_fenetre*0.325 <= fltk.abscisse_souris() <= taille_fenetre*0.675 :
                    efface_multiple_objets(menu_fin_partie)
                    info["statut_partie"] = True
                    sauvegarder_jeu(info)
                    return "menu"

def manche(partie_info) :
    """
    Generer une manche du jeu
    : param info: (dict) informations sur la partie
    : return (str): decision "jouer","quitter","menu"
    """
    limite_points = partie_info["limite_points"]
    nombre_joueurs = partie_info["nombre_joueurs"]
    noms_joueurs = partie_info["noms_joueurs"]
    couleurs_joueurs = partie_info["couleurs_joueurs"]
    couleurs_boules = partie_info["couleurs_boules"]
    index_couleur = partie_info["index_couleur"]
    
    score_manche = partie_info["score_manche"]

    if configuration["theme_interface"] == 0 :
        couleur_trait = 'black'
        couleur_externe = '#F1E3A4'
    else :
        couleur_trait = 'white'
        couleur_externe = '#010014'
    
    def obtenir_statut_boules(couleurs_boules) :
        statut_boules = []
        for i in couleurs_boules :
            statut_boules_row = []
            for j in i :
                if j == None :
                    statut_boules_row.append(False)
                else :
                    statut_boules_row.append(True)
            statut_boules.append(statut_boules_row)
            
        return statut_boules
    
    fltk.efface_tout()
    charger_plateau_jeu(configuration["mode_plateau"], partie_info)
    
    sauvegarde_partie_couleurs = dict()
    
    statut_boules = obtenir_statut_boules(partie_info["couleurs_boules"])
    
    moves = 0
    moves_copy = 0

    boule_ce_coup = []
    
    if partie_info["statut_manche"] == True :
        rc = fltk.rectangle(taille_fenetre*0.350,taille_fenetre*0.350,taille_fenetre*0.650,taille_fenetre*0.650,couleur_trait,couleur_externe,taille_fenetre*0.003)    
        
        if nombre_joueurs != 1 :
            partie_info["index_couleur"] = random.randint(0,nombre_joueurs-1)
        
        partie_info["index_couleur"] = 0
        boule = dessiner_forme(configuration["mode_boules"],taille_fenetre*0.500,taille_fenetre*0.500,taille_fenetre*0.080,couleurs_joueurs[partie_info["index_couleur"]])            
        
        texte = fltk.texte(taille_fenetre*0.500,taille_fenetre*0.605,f"{noms_joueurs[partie_info['index_couleur']]} {IU_TEXTE['jeu_selection_commence'][configuration['index_langue']]}", couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration['index_police']],taille=int(taille_fenetre*0.018))
        partie_info["index_couleur"] += 1
        eve = fltk.attend_ev()
        ty_eve = fltk.type_ev(eve)
        if ty_eve == "Quitte" :
            return "quitter"
        partie_info["statut_manche"] = False
        efface_multiple_objets(boule)
        fltk.efface(rc)
        fltk.efface(texte)
    
    is_pause = False

    cercle_clignotant,cercle_clignotant_mini1,cercle_clignotant_mini2 = boules_indiquer_tour_joueur(partie_info)
    
    nombre_manches = fltk.texte(taille_fenetre*0.500,taille_fenetre*0.040,f"{IU_TEXTE['menu_jeu_nmanches'][configuration['index_langue']]} : {partie_info['nombre_manches']}",couleur=couleur_trait,ancrage="center",police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.021))
    
    if nombre_joueurs == 4 :
        nom_score1 = fltk.texte(taille_fenetre*0.155,taille_fenetre*0.090,f"{noms_joueurs[0]} : {partie_info['score_manche'][0]}",couleur=couleur_trait,ancrage="center",police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.018))
        nom_score2 = fltk.texte(taille_fenetre*0.385,taille_fenetre*0.090,f"{noms_joueurs[1]} : {partie_info['score_manche'][1]}",couleur=couleur_trait,ancrage="center",police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.018))
        nom_score3 = fltk.texte(taille_fenetre*0.615,taille_fenetre*0.090,f"{noms_joueurs[2]} : {partie_info['score_manche'][2]}",couleur=couleur_trait,ancrage="center",police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.018))
        nom_score4 = fltk.texte(taille_fenetre*0.845,taille_fenetre*0.090,f"{noms_joueurs[3]} : {partie_info['score_manche'][3]}",couleur=couleur_trait,ancrage="center",police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.018))
    if nombre_joueurs == 3 :
        nom_score1 = fltk.texte(taille_fenetre*0.250,taille_fenetre*0.090,f"{noms_joueurs[0]} : {partie_info['score_manche'][0]}",couleur=couleur_trait,ancrage="center",police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.018))
        nom_score2 = fltk.texte(taille_fenetre*0.500,taille_fenetre*0.090,f"{noms_joueurs[1]} : {partie_info['score_manche'][1]}",couleur=couleur_trait,ancrage="center",police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.018))
        nom_score3 = fltk.texte(taille_fenetre*0.750,taille_fenetre*0.090,f"{noms_joueurs[2]} : {partie_info['score_manche'][2]}",couleur=couleur_trait,ancrage="center",police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.018))
    if nombre_joueurs in [1,2] :
        nom_score1 = fltk.texte(taille_fenetre*0.300,taille_fenetre*0.090,f"{noms_joueurs[0]} : {partie_info['score_manche'][0]}",couleur=couleur_trait,ancrage="center",police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.018))
        nom_score2 = fltk.texte(taille_fenetre*0.700,taille_fenetre*0.090,f"{noms_joueurs[1]} : {partie_info['score_manche'][1]}",couleur=couleur_trait,ancrage="center",police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.018))
    
    while len(boules_sur_plateau(statut_boules)) < 64 :
        ev = fltk.attend_ev()
        tev = fltk.type_ev(ev)
        if tev == "Quitte":
            return "quitter"
        elif tev == "ClicGauche":
            if not is_pause :
                if taille_fenetre*0.010 <= fltk.ordonnee_souris() <= taille_fenetre*0.060 :
                    if taille_fenetre*0.010 <= fltk.abscisse_souris() <= taille_fenetre*0.060 :
                        is_pause = True
                        pause = menu_pause()
                        if pause == "quitter" :
                            return "quitter"
                        elif pause == "menu" :
                            return "menu"
                        elif pause == "jouer" :
                            is_pause = False
                            return "jouer"
                    
            if not is_pause :
                if obtenir_info_clic(statut_boules) == True :
                    if nombre_joueurs == 4 or nombre_joueurs == 3 :
                        if partie_info["index_couleur"] == 1 :
                            couleur_initiale = couleurs_joueurs[0]
                        elif partie_info["index_couleur"] == 2 :
                            couleur_initiale = couleurs_joueurs[1]
                        elif partie_info["index_couleur"] == 3 :
                            couleur_initiale = couleurs_joueurs[2]
                        elif partie_info["index_couleur"] == 4 :
                            couleur_initiale = couleurs_joueurs[3]
                    if nombre_joueurs == 2 :
                        if partie_info["index_couleur"] == 1 :
                            couleur_initiale = couleurs_joueurs[0]
                        elif partie_info["index_couleur"] == 2 :
                            couleur_initiale = couleurs_joueurs[1]
                    if nombre_joueurs == 1 :
                        if partie_info["index_couleur"] == 1 :
                            couleur_initiale = couleurs_joueurs[0]
                        elif partie_info["index_couleur"] == 2 :
                            couleur_initiale = couleurs_joueurs[1]

                    last_move = copy.deepcopy(partie_info["couleurs_boules"])
                    
                    if nombre_joueurs == 1 :
                        poser_boule(partie_info["couleurs_boules"],statut_boules,couleur_initiale)
                        partie_info["index_couleur"] += 1
                    else :
                        poser_boule(partie_info["couleurs_boules"],statut_boules,couleur_initiale)
                        partie_info["index_couleur"] += 1
                                            
                    for ligne,liste in enumerate(partie_info["couleurs_boules"]) :
                        for colonne,couleur in enumerate(liste) :
                            if couleur != None :
                                boule_ce_coup.append(dessiner_forme(configuration["mode_boules"],CORDONNE_CENTRE_BOULES[ligne][colonne][0],CORDONNE_CENTRE_BOULES[ligne][colonne][1],taille_fenetre*0.036,couleur))
                    
                    retour_rec = fltk.rectangle(taille_fenetre*0.080,taille_fenetre*0.010,taille_fenetre*0.400,taille_fenetre*0.060,couleur_trait,couleur_externe,taille_fenetre*0.003)
                    retour_texte = fltk.texte(taille_fenetre*0.240,taille_fenetre*0.035,IU_TEXTE['menu_jeu_retour'][configuration["index_langue"]],couleur=couleur_trait,ancrage="center",police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.016))
                    continue_rec = fltk.rectangle(taille_fenetre*0.600,taille_fenetre*0.010,taille_fenetre*0.920,taille_fenetre*0.060,couleur_trait,couleur_externe,taille_fenetre*0.003)
                    continue_texte = fltk.texte(taille_fenetre*0.760,taille_fenetre*0.035,IU_TEXTE['menu_jeu_continue'][configuration["index_langue"]],couleur=couleur_trait,ancrage="center",police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.016))
                    
                    new_ev = fltk.attend_ev()
                    new_tev = fltk.type_ev(new_ev)

                    efface_multiple_objets([cercle_clignotant,cercle_clignotant_mini1,cercle_clignotant_mini2])

                    if new_tev == "Quitte":
                        return False,[]
                    elif new_tev == "ClicGauche":
                        efface_multiple_objets([continue_texte,continue_rec,retour_texte,retour_rec])
                        if nombre_joueurs == 1 : 
                            if partie_info["index_couleur"] == 1 :
                                couleur_initiale = couleurs_joueurs[0]
                            elif partie_info["index_couleur"] == 2 :
                                couleur_initiale = couleurs_joueurs[1]
                            poser_boule_aleatoire(partie_info["couleurs_boules"],statut_boules,couleur_initiale)
                            for ligne,liste in enumerate(partie_info["couleurs_boules"]) :
                                for colonne,couleur in enumerate(liste) :
                                    if couleur != None :
                                        boule_ce_coup.append(dessiner_forme(configuration["mode_boules"],CORDONNE_CENTRE_BOULES[ligne][colonne][0],CORDONNE_CENTRE_BOULES[ligne][colonne][1],taille_fenetre*0.036,couleur))
                        boule_ce_coup.clear()
                    
                    elif new_tev == "ClicDroit":
                        efface_multiple_objets([continue_texte,continue_rec,retour_texte,retour_rec])
                        partie_info["index_couleur"] -= 1
                        partie_info["couleurs_boules"] = copy.deepcopy(last_move)
                        last_move.clear()
                        for b in boule_ce_coup :    
                            efface_multiple_objets(b)
                        boule_ce_coup.clear()
                    
                    statut_boules = obtenir_statut_boules(partie_info["couleurs_boules"])

                    if partie_info["index_couleur"] > nombre_joueurs :
                        partie_info["index_couleur"] = 1
                    if partie_info["index_couleur"] < 1 :
                        partie_info["index_couleur"] = nombre_joueurs
                    cercle_clignotant,cercle_clignotant_mini1,cercle_clignotant_mini2 = boules_indiquer_tour_joueur(partie_info)

            else :
                if taille_fenetre*0.300 <= fltk.abscisse_souris() <= taille_fenetre*0.700:
                    if taille_fenetre*0.400 <= fltk.ordonnee_souris() <= taille_fenetre*0.500 :
                        is_pause = False
                        efface_multiple_objets(pause)
                    elif taille_fenetre*0.525 <= fltk.ordonnee_souris() <= taille_fenetre*0.625 :
                        print("apres apres")
                    elif taille_fenetre*0.650 <= fltk.ordonnee_souris() <= taille_fenetre*0.750 :
                        return "menu"
            
        elif tev == "ClicDroit" :
            if moves_copy > 1 :
                moves_copy -= 1
                partie_info["index_couleur"] -= 1
                if partie_info["index_couleur"] < 1 :
                    partie_info["index_couleur"] = nombre_joueurs
        
        if nombre_joueurs != 1 :
            n_tem = nombre_joueurs
        else :
            n_tem = 2
                        
        partie_info["score_manche"] = [0 for i in range(n_tem)]
        
        for i in couleurs_boules :
            for j in i :
                for x,couleur in enumerate(couleurs_joueurs) :
                    if x < n_tem :
                        if j == couleur :
                            partie_info["score_manche"][x] += 1
                 
        if nombre_joueurs == 4 :
            efface_multiple_objets([nom_score1,nom_score2,nom_score3,nom_score4])
            nom_score1 = fltk.texte(taille_fenetre*0.155,taille_fenetre*0.090,f"{noms_joueurs[0]} : {partie_info['score_manche'][0]}",couleur=couleur_trait,ancrage="center",police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.018))
            nom_score2 = fltk.texte(taille_fenetre*0.385,taille_fenetre*0.090,f"{noms_joueurs[1]} : {partie_info['score_manche'][1]}",couleur=couleur_trait,ancrage="center",police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.018))
            nom_score3 = fltk.texte(taille_fenetre*0.615,taille_fenetre*0.090,f"{noms_joueurs[2]} : {partie_info['score_manche'][2]}",couleur=couleur_trait,ancrage="center",police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.018))
            nom_score4 = fltk.texte(taille_fenetre*0.845,taille_fenetre*0.090,f"{noms_joueurs[3]} : {partie_info['score_manche'][3]}",couleur=couleur_trait,ancrage="center",police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.018))
        if nombre_joueurs == 3 :
            efface_multiple_objets([nom_score1,nom_score2,nom_score3])
            nom_score1 = fltk.texte(taille_fenetre*0.250,taille_fenetre*0.090,f"{noms_joueurs[0]} : {partie_info['score_manche'][0]}",couleur=couleur_trait,ancrage="center",police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.018))
            nom_score2 = fltk.texte(taille_fenetre*0.500,taille_fenetre*0.090,f"{noms_joueurs[1]} : {partie_info['score_manche'][1]}",couleur=couleur_trait,ancrage="center",police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.018))
            nom_score3 = fltk.texte(taille_fenetre*0.750,taille_fenetre*0.090,f"{noms_joueurs[2]} : {partie_info['score_manche'][2]}",couleur=couleur_trait,ancrage="center",police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.018))
        if nombre_joueurs in [1,2] :
            efface_multiple_objets([nom_score1,nom_score2])
            nom_score1 = fltk.texte(taille_fenetre*0.300,taille_fenetre*0.090,f"{noms_joueurs[0]} : {partie_info['score_manche'][0]}",couleur=couleur_trait,ancrage="center",police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.018))
            nom_score2 = fltk.texte(taille_fenetre*0.700,taille_fenetre*0.090,f"{noms_joueurs[1]} : {partie_info['score_manche'][1]}",couleur=couleur_trait,ancrage="center",police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.018))
        
        sauvegarder_jeu(partie_info)
        
        fltk.mise_a_jour()
    
    else :
        sauvegarder_jeu(partie_info)
        
        fin_manche = menu_fin_manche(partie_info)
        
        if fin_manche == "jouer" :
            if nombre_joueurs != 1 :
                for i in range(len(partie_info["score_manche"])) :
                    partie_info["score_total"][i] += partie_info["score_manche"][i]  
                partie_info["score_manche"] = [1 for _ in range(nombre_joueurs)]
            else :
                for i in range(2) :
                    partie_info["score_total"][i] += partie_info["score_manche"][i]
                partie_info["score_manche"] = [1 for _ in range(2)]
            
            partie_info["couleurs_boules"] = copy.deepcopy(partie_info["couleurs_boules_init"])
            partie_info["statut_manche"] = True    
            print(partie_info["score_total"])

def sauvegarder_jeu(state, filename="save_game.json"):
    """
    Sauvegarder une partie
    """
    with open(filename, "w") as file:
        json.dump(state, file)

def restaurer_jeu(filename="save_game.json"):
    """
    Restaurer la partie sauvegardee
    """
    try:
        with open(filename, "r") as file:
            state = json.load(file)
        return state

    except FileNotFoundError:
        return None

def partie() :
    """
    Generer une partie du jeu
    : return (str): decision "jouer","quitter","menu"
    """
    partie_info = restaurer_jeu()
    limite_points = partie_info["limite_points"]
    nombre_joueurs = partie_info["nombre_joueurs"]
    noms_joueurs = partie_info["noms_joueurs"]
    couleurs_joueurs = partie_info["couleurs_joueurs"]
    couleurs_boules = partie_info["couleurs_boules"]
    
    #partie_info["score_total"] = [0 for i in range(partie_info["nombre_joueurs"])]
    score_total = partie_info["score_total"]
    
    fltk.efface_tout()
    
    while True :
        for score in partie_info["score_total"] :
            if score >= limite_points :
                jouer_partie = menu_fin_partie(partie_info)
                if jouer_partie == "quitter" :
                    return "quitter"
                if jouer_partie == "menu" :
                    return "menu"
            
        jouer = manche(partie_info)
            
        sauvegarder_jeu(partie_info)
            
        if jouer == "quitter" :
            return "quitter"
        elif jouer == "menu" :
            return "menu"
        elif jouer == "jouer" :
            continue

    return "menu"

def charger_menu_prepartie() :
    """
    Dessiner le menu prepartie
    """
    fltk.efface_tout()
    if configuration["theme_interface"] == 1 :
        fltk.rectangle(0,0,taille_fenetre,hauteur_fenetre,'#010014','#010014')
        couleur_trait = 'white'
        couleur_inverse = 'black'
    if configuration["theme_interface"] == 0 :
        fltk.rectangle(0,0,taille_fenetre,hauteur_fenetre,'#F1E3A4','#F1E3A4')
        couleur_trait = 'black'
        couleur_inverse = 'white'
        
    n_joueurs = 4 #default
    limite_points = 100 #default
    
    SELECT_NJOUEURS_CENTRES = [taille_fenetre*0.355,taille_fenetre*0.475,taille_fenetre*0.595,taille_fenetre*0.715]
    SELECT_LPOINTS_CENTRES = [taille_fenetre*0.355,taille_fenetre*0.475,taille_fenetre*0.595,taille_fenetre*0.715,taille_fenetre*0.835]
    
    #button à commecner la partie
    fltk.rectangle(taille_fenetre*0.300,taille_fenetre*0.550,taille_fenetre*0.700,taille_fenetre*0.650,couleur_trait,couleur_inverse)
    fltk.texte(taille_fenetre*0.500, taille_fenetre*0.600, IU_TEXTE['menu_principal_jouer'][configuration["index_langue"]], couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.024))
    
    #button à revenir au menu
    fltk.rectangle(taille_fenetre*0.300,taille_fenetre*0.700,taille_fenetre*0.700,taille_fenetre*0.800,couleur_trait,couleur_inverse)
    fltk.texte(taille_fenetre*0.500, taille_fenetre*0.750, IU_TEXTE['menu_options_menu'][configuration["index_langue"]], couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.024))
    
    fltk.texte(taille_fenetre*0.180, taille_fenetre*0.400, IU_TEXTE['menu_prepartie_njoueurs'][configuration["index_langue"]], couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.018))
    #
    fltk.texte(taille_fenetre*0.395, taille_fenetre*0.400, "CPU", couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.016))
    fltk.rectangle(taille_fenetre*0.345,taille_fenetre*0.390,taille_fenetre*0.365,taille_fenetre*0.410,couleur_trait,couleur_inverse,taille_fenetre*0.003)
    fltk.texte(taille_fenetre*0.500, taille_fenetre*0.400, "2", couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.016))
    fltk.rectangle(taille_fenetre*0.465,taille_fenetre*0.390,taille_fenetre*0.485,taille_fenetre*0.410,couleur_trait,couleur_inverse,taille_fenetre*0.003)
    fltk.texte(taille_fenetre*0.620, taille_fenetre*0.400, "3", couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.016))
    fltk.rectangle(taille_fenetre*0.585,taille_fenetre*0.390,taille_fenetre*0.605,taille_fenetre*0.410,couleur_trait,couleur_inverse,taille_fenetre*0.003)
    fltk.texte(taille_fenetre*0.740, taille_fenetre*0.400, "4", couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.016))
    fltk.rectangle(taille_fenetre*0.705,taille_fenetre*0.390,taille_fenetre*0.725,taille_fenetre*0.410,couleur_trait,couleur_inverse,taille_fenetre*0.003)
    
    fltk.texte(taille_fenetre*0.180, taille_fenetre*0.460, IU_TEXTE['menu_prepartie_lpoints'][configuration["index_langue"]], couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.018))
    #
    fltk.texte(taille_fenetre*0.400, taille_fenetre*0.460, "100", couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.016))
    fltk.rectangle(taille_fenetre*0.345,taille_fenetre*0.450,taille_fenetre*0.365,taille_fenetre*0.470,couleur_trait,couleur_inverse,taille_fenetre*0.003)
    fltk.texte(taille_fenetre*0.520, taille_fenetre*0.460, "250", couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.016))
    fltk.rectangle(taille_fenetre*0.465,taille_fenetre*0.450,taille_fenetre*0.485,taille_fenetre*0.470,couleur_trait,couleur_inverse,taille_fenetre*0.003)
    fltk.texte(taille_fenetre*0.640, taille_fenetre*0.460, "450", couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.016))
    fltk.rectangle(taille_fenetre*0.585,taille_fenetre*0.450,taille_fenetre*0.605,taille_fenetre*0.470,couleur_trait,couleur_inverse,taille_fenetre*0.003)
    fltk.texte(taille_fenetre*0.760, taille_fenetre*0.460, "700", couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.016))
    fltk.rectangle(taille_fenetre*0.705,taille_fenetre*0.450,taille_fenetre*0.725,taille_fenetre*0.470,couleur_trait,couleur_inverse,taille_fenetre*0.003)
    fltk.texte(taille_fenetre*0.880, taille_fenetre*0.460, "1000", couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.016))
    fltk.rectangle(taille_fenetre*0.825,taille_fenetre*0.450,taille_fenetre*0.845,taille_fenetre*0.470,couleur_trait,couleur_inverse,taille_fenetre*0.003)
    
    cercle_joueur = 1
    cercle_points = 2
    
    while True :
        while True :
            if configuration["theme_interface"] == 0 :
                couleur_selectionne = 'black'
            else :
                couleur_selectionne = 'white'
                    
            if n_joueurs == 1 :
                cercle_joueur = fltk.cercle(SELECT_NJOUEURS_CENTRES[0],taille_fenetre*0.400,taille_fenetre*0.007,couleur_selectionne,couleur_selectionne)
            elif n_joueurs == 2 :
                cercle_joueur = fltk.cercle(SELECT_NJOUEURS_CENTRES[1],taille_fenetre*0.400,taille_fenetre*0.007,couleur_selectionne,couleur_selectionne)
            elif n_joueurs == 3 :
                cercle_joueur = fltk.cercle(SELECT_NJOUEURS_CENTRES[2],taille_fenetre*0.400,taille_fenetre*0.007,couleur_selectionne,couleur_selectionne)
            elif n_joueurs == 4 :
                cercle_joueur = fltk.cercle(SELECT_NJOUEURS_CENTRES[3],taille_fenetre*0.400,taille_fenetre*0.007,couleur_selectionne,couleur_selectionne)
            
            if limite_points == 100 :
                cercle_points = fltk.cercle(SELECT_LPOINTS_CENTRES[0],taille_fenetre*0.460,taille_fenetre*0.007,couleur_selectionne,couleur_selectionne)
            elif limite_points == 250 :
                cercle_points = fltk.cercle(SELECT_LPOINTS_CENTRES[1],taille_fenetre*0.460,taille_fenetre*0.007,couleur_selectionne,couleur_selectionne)
            elif limite_points == 450 :
                cercle_points = fltk.cercle(SELECT_LPOINTS_CENTRES[2],taille_fenetre*0.460,taille_fenetre*0.007,couleur_selectionne,couleur_selectionne)
            elif limite_points == 700 :
                cercle_points = fltk.cercle(SELECT_LPOINTS_CENTRES[0],taille_fenetre*0.460,taille_fenetre*0.007,couleur_selectionne,couleur_selectionne)
            elif limite_points == 1000 :
                cercle_points = fltk.cercle(SELECT_LPOINTS_CENTRES[1],taille_fenetre*0.460,taille_fenetre*0.007,couleur_selectionne,couleur_selectionne)

            nv_clic = fltk.attend_ev()
            nv_ty_clic = fltk.type_ev(nv_clic)
            
            fltk.efface(cercle_joueur)
            fltk.efface(cercle_points)
                    
            if nv_ty_clic == "ClicGauche" :
                if taille_fenetre*0.390 <= fltk.ordonnee_souris() <= taille_fenetre*0.410 :
                    if taille_fenetre*0.345 <= fltk.abscisse_souris() <= taille_fenetre*0.365 :
                        n_joueurs = 1
                    if taille_fenetre*0.465 <= fltk.abscisse_souris() <= taille_fenetre*0.485 :
                        n_joueurs = 2
                    if taille_fenetre*0.585 <= fltk.abscisse_souris() <= taille_fenetre*0.605 :
                        n_joueurs = 3
                    if taille_fenetre*0.705 <= fltk.abscisse_souris() <= taille_fenetre*0.725 :
                        n_joueurs = 4
                        
                elif taille_fenetre*0.450 <= fltk.ordonnee_souris() <= taille_fenetre*0.470 :
                    if taille_fenetre*0.345 <= fltk.abscisse_souris() <= taille_fenetre*0.365 :
                        limite_points = 100
                    if taille_fenetre*0.465 <= fltk.abscisse_souris() <= taille_fenetre*0.485 :
                        limite_points = 250
                    if taille_fenetre*0.585 <= fltk.abscisse_souris() <= taille_fenetre*0.605 :
                        limite_points = 450
                    if taille_fenetre*0.705 <= fltk.abscisse_souris() <= taille_fenetre*0.725 :
                        limite_points = 700
                    if taille_fenetre*0.825 <= fltk.abscisse_souris() <= taille_fenetre*0.845 :
                        limite_points = 1000
                    
                elif taille_fenetre*0.550 <= fltk.ordonnee_souris() <= taille_fenetre*0.650 :
                    if taille_fenetre*0.300 <= fltk.abscisse_souris() <= taille_fenetre*0.700 :
                        break
                elif taille_fenetre*0.700 <= fltk.ordonnee_souris() <= taille_fenetre*0.800 :
                    if taille_fenetre*0.300 <= fltk.abscisse_souris() <= taille_fenetre*0.700 :
                        return "menu"

            elif nv_ty_clic == "Quitte" :
                return "quitter"
        
        jouer = charger_menu_prepartie_info_joueurs(n_joueurs,limite_points)
        if jouer == "jouer" :
            return "jouer"
        elif jouer == "quitter" :
            return "quitter"
        elif jouer == "menu" :
            return "menu"
        
def charger_menu_prepartie_info_joueurs(nombre_joueurs,limite_points) :
    """
    Dessiner le deuxieme menu prepartie
    """
    partie_info = dict()
    if nombre_joueurs == 1 :
        partie_info["nombre_joueurs"] = 2
    else :
        partie_info["nombre_joueurs"] = nombre_joueurs
    partie_info["limite_points"] = limite_points
    partie_info["noms_joueurs"] = ["" for _ in range(partie_info["nombre_joueurs"])]
    partie_info["couleurs_joueurs"] = ["non" for _ in range(4)]
    partie_info["index_couleur"] = 1
    
    maj = False
    
    for _ in range(nombre_joueurs) :
        fltk.efface_tout()
        if configuration["theme_interface"] == 1 : #010014 17202A
            fltk.rectangle(0,0,taille_fenetre,hauteur_fenetre,'#010014','#010014')
            couleur_trait = 'white'
            couleur_inverse = 'black'
        if configuration["theme_interface"] == 0 :
            fltk.rectangle(0,0,taille_fenetre,hauteur_fenetre,'#F1E3A4','#F1E3A4')
            couleur_trait = 'black'
            couleur_inverse = 'white'
        
        #button à commecner la partie
        if _ == nombre_joueurs - 1 :
            fltk.rectangle(taille_fenetre*0.300,taille_fenetre*0.700,taille_fenetre*0.700,taille_fenetre*0.800,couleur_trait,couleur_inverse)
            fltk.texte(taille_fenetre*0.500, taille_fenetre*0.750, IU_TEXTE['menu_principal_jouer'][configuration["index_langue"]], couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.024))
        else :
            fltk.rectangle(taille_fenetre*0.300,taille_fenetre*0.700,taille_fenetre*0.700,taille_fenetre*0.800,couleur_trait,couleur_inverse)
            fltk.texte(taille_fenetre*0.500, taille_fenetre*0.750, IU_TEXTE['menu_prepartie_suivant'][configuration["index_langue"]], couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.024))
        
        #button à revenir au menu
        fltk.rectangle(taille_fenetre*0.300,taille_fenetre*0.850,taille_fenetre*0.700,taille_fenetre*0.950,couleur_trait,couleur_inverse)
        fltk.texte(taille_fenetre*0.500, taille_fenetre*0.900, IU_TEXTE['menu_options_menu'][configuration["index_langue"]], couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.024))
        
        #button majuscule
        fltk.rectangle(taille_fenetre*0.100,taille_fenetre*0.300,taille_fenetre*0.200,taille_fenetre*0.400,couleur_trait,couleur_inverse)

        fltk.texte(taille_fenetre*0.500, taille_fenetre*0.130, f"Player {_+1}", couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.030))
        
        fltk.texte(taille_fenetre*0.500, taille_fenetre*0.250, "Nom :", couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.024))
        fltk.rectangle(taille_fenetre*0.250,taille_fenetre*0.300,taille_fenetre*0.750,taille_fenetre*0.400,couleur_trait,couleur_inverse)
        
        #red orange yellow green blue indigo pink
        SELECT_COULEURS_CENTRES = [taille_fenetre*0.200,taille_fenetre*0.300,taille_fenetre*0.400,taille_fenetre*0.500,taille_fenetre*0.600,taille_fenetre*0.700,taille_fenetre*0.800]
        
        fltk.cercle(taille_fenetre*0.200,taille_fenetre*0.530,taille_fenetre*0.025,couleur_trait,'#E61D24',taille_fenetre*0.001)
        if "red" not in partie_info["couleurs_joueurs"] :
            fltk.rectangle(taille_fenetre*0.190,taille_fenetre*0.590,taille_fenetre*0.210,taille_fenetre*0.610,couleur_trait,couleur_inverse,taille_fenetre*0.003)
        
        fltk.cercle(taille_fenetre*0.300,taille_fenetre*0.530,taille_fenetre*0.025,couleur_trait,'#E97818',taille_fenetre*0.001)
        if "orange" not in partie_info["couleurs_joueurs"] :
            fltk.rectangle(taille_fenetre*0.290,taille_fenetre*0.590,taille_fenetre*0.310,taille_fenetre*0.610,couleur_trait,couleur_inverse,taille_fenetre*0.003)
        
        fltk.cercle(taille_fenetre*0.400,taille_fenetre*0.530,taille_fenetre*0.025,couleur_trait,'#FAE202',taille_fenetre*0.001)
        if "yellow" not in partie_info["couleurs_joueurs"] :
            fltk.rectangle(taille_fenetre*0.390,taille_fenetre*0.590,taille_fenetre*0.410,taille_fenetre*0.610,couleur_trait,couleur_inverse,taille_fenetre*0.003)
        
        fltk.cercle(taille_fenetre*0.500,taille_fenetre*0.530,taille_fenetre*0.025,couleur_trait,'#308D2F',taille_fenetre*0.001)
        if "green" not in partie_info["couleurs_joueurs"] :
            fltk.rectangle(taille_fenetre*0.490,taille_fenetre*0.590,taille_fenetre*0.510,taille_fenetre*0.610,couleur_trait,couleur_inverse,taille_fenetre*0.003)
        
        fltk.cercle(taille_fenetre*0.600,taille_fenetre*0.530,taille_fenetre*0.025,couleur_trait,'#0083C4',taille_fenetre*0.001)
        if "blue" not in partie_info["couleurs_joueurs"] :
            fltk.rectangle(taille_fenetre*0.590,taille_fenetre*0.590,taille_fenetre*0.610,taille_fenetre*0.610,couleur_trait,couleur_inverse,taille_fenetre*0.003)
        
        fltk.cercle(taille_fenetre*0.700,taille_fenetre*0.530,taille_fenetre*0.025,couleur_trait,'#762CBF',taille_fenetre*0.001)
        if "indigo" not in partie_info["couleurs_joueurs"] :
            fltk.rectangle(taille_fenetre*0.690,taille_fenetre*0.590,taille_fenetre*0.710,taille_fenetre*0.610,couleur_trait,couleur_inverse,taille_fenetre*0.003)
        
        fltk.cercle(taille_fenetre*0.800,taille_fenetre*0.530,taille_fenetre*0.025,couleur_trait,'#F249C5',taille_fenetre*0.001)
        if "pink" not in partie_info["couleurs_joueurs"] :
            fltk.rectangle(taille_fenetre*0.790,taille_fenetre*0.590,taille_fenetre*0.810,taille_fenetre*0.610,couleur_trait,couleur_inverse,taille_fenetre*0.003)

        color_selected = False
        couleur = ""
        name = ""
        name_typed = False
        cercle_couleur = 0
        
        while True :
            if configuration["theme_interface"] == 0 :
                couleur_selectionne = 'black'
            else :
                couleur_selectionne = 'white'
                
            name_affiche = fltk.texte(taille_fenetre*0.500, taille_fenetre*0.350, f"{name}", couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.024))
        
            if maj :
                maj_min = fltk.texte(taille_fenetre*0.150, taille_fenetre*0.350, 'min', couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.018))
            else :
                maj_min = fltk.texte(taille_fenetre*0.150, taille_fenetre*0.350, 'MAJ', couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.018))
        
            if couleur == "red" :
                cercle_couleur = fltk.cercle(SELECT_COULEURS_CENTRES[0],taille_fenetre*0.600,taille_fenetre*0.007,couleur_selectionne,couleur_selectionne)
            if couleur == "orange" :
                cercle_couleur = fltk.cercle(SELECT_COULEURS_CENTRES[1],taille_fenetre*0.600,taille_fenetre*0.007,couleur_selectionne,couleur_selectionne)
            if couleur == "yellow" :
                cercle_couleur = fltk.cercle(SELECT_COULEURS_CENTRES[2],taille_fenetre*0.600,taille_fenetre*0.007,couleur_selectionne,couleur_selectionne)
            if couleur == "green" :
                cercle_couleur = fltk.cercle(SELECT_COULEURS_CENTRES[3],taille_fenetre*0.600,taille_fenetre*0.007,couleur_selectionne,couleur_selectionne)
            if couleur == "blue" :
                cercle_couleur = fltk.cercle(SELECT_COULEURS_CENTRES[4],taille_fenetre*0.600,taille_fenetre*0.007,couleur_selectionne,couleur_selectionne)
            if couleur == "indigo" :
                cercle_couleur = fltk.cercle(SELECT_COULEURS_CENTRES[5],taille_fenetre*0.600,taille_fenetre*0.007,couleur_selectionne,couleur_selectionne)
            if couleur == "pink" :
                cercle_couleur = fltk.cercle(SELECT_COULEURS_CENTRES[6],taille_fenetre*0.600,taille_fenetre*0.007,couleur_selectionne,couleur_selectionne)
                
            clic = fltk.attend_ev()
            ty_clic = fltk.type_ev(clic)
            
            fltk.efface(cercle_couleur)
            fltk.efface(name_affiche)
            fltk.efface(maj_min)
            
            if ty_clic == "Touche" :
                if  fltk.touche(clic) != "BackSpace" :
                    if fltk.touche(clic) in TOUCHES_POSSIBLES :
                        def min_or_maj(char,maj) :
                            chars_min = 'azertyuiopqsdfghjklmwxcvbn'
                            chars_maj = 'AZERTYUIOPQSDFGHJKLMWXCVBN'
                            
                            if char in chars_min :
                                if maj :
                                    return chars_maj[chars_min.index(char)]
                                
                            return char
                                
                        if len(name) < 8 :
                            name += min_or_maj(fltk.touche(clic),maj)
                            print(fltk.touche(clic))
                else :
                    name = name[:-1]
                    
            elif ty_clic == "ClicGauche" :
                if taille_fenetre*0.300 <= fltk.ordonnee_souris() <= taille_fenetre*0.400 :
                    if taille_fenetre*0.100 <= fltk.abscisse_souris() <= taille_fenetre*0.200 :
                        maj = not maj
                        
                if taille_fenetre*0.590 <= fltk.ordonnee_souris() <= taille_fenetre*0.610 :
                    if taille_fenetre*0.190 <= fltk.abscisse_souris() <= taille_fenetre*0.210 :
                        if "red" not in partie_info["couleurs_joueurs"] :
                            couleur = "red"
                            color_selected = True
                    if taille_fenetre*0.290 <= fltk.abscisse_souris() <= taille_fenetre*0.310 :
                        if "orange" not in partie_info["couleurs_joueurs"] :
                            couleur = "orange"
                            color_selected = True
                    if taille_fenetre*0.390 <= fltk.abscisse_souris() <= taille_fenetre*0.410 :
                        if "yellow" not in partie_info["couleurs_joueurs"] :
                            couleur = "yellow"
                            color_selected = True
                    if taille_fenetre*0.490 <= fltk.abscisse_souris() <= taille_fenetre*0.510 :
                        if "green" not in partie_info["couleurs_joueurs"] :
                            couleur = "green"
                            color_selected = True
                    if taille_fenetre*0.590 <= fltk.abscisse_souris() <= taille_fenetre*0.610 :
                        if "blue" not in partie_info["couleurs_joueurs"] :
                            couleur = "blue"
                            color_selected = True
                    if taille_fenetre*0.690 <= fltk.abscisse_souris() <= taille_fenetre*0.710 :
                        if "indigo" not in partie_info["couleurs_joueurs"] :
                            couleur = "indigo"
                            color_selected = True
                    if taille_fenetre*0.790 <= fltk.abscisse_souris() <= taille_fenetre*0.810 :
                        if "pink" not in partie_info["couleurs_joueurs"] :
                            couleur = "pink"
                            color_selected = True
                    
                elif taille_fenetre*0.700 <= fltk.ordonnee_souris() <= taille_fenetre*0.800 :
                    if taille_fenetre*0.300 <= fltk.abscisse_souris() <= taille_fenetre*0.700 :
                        if color_selected and len(name) > 2 : 
                            partie_info["couleurs_joueurs"][_] = couleur
                            partie_info["noms_joueurs"][_] = name
                            break
                elif taille_fenetre*0.850 <= fltk.ordonnee_souris() <= taille_fenetre*0.950 :
                    if taille_fenetre*0.300 <= fltk.abscisse_souris() <= taille_fenetre*0.700 :
                        return "menu"

            elif ty_clic == "Quitte" :
                return "quitter"
    
    if  nombre_joueurs in [3,4] :
        partie_info["couleurs_boules"] = [[None for i in range(8)] for j in range(8)]
        partie_info["couleurs_boules"][3][3] = partie_info["couleurs_joueurs"][0]
        partie_info["couleurs_boules"][3][4] = partie_info["couleurs_joueurs"][1]
        partie_info["couleurs_boules"][4][4] = partie_info["couleurs_joueurs"][2]
        partie_info["couleurs_boules"][4][3] = partie_info["couleurs_joueurs"][3]
                
    if  nombre_joueurs == 2 :
        partie_info["couleurs_boules"] = [[None for i in range(8)] for j in range(8)]
        
        partie_info["couleurs_boules"][3][3] = partie_info["couleurs_joueurs"][0]
        partie_info["couleurs_boules"][3][4] = partie_info["couleurs_joueurs"][2]
        partie_info["couleurs_boules"][4][4] = partie_info["couleurs_joueurs"][1]
        partie_info["couleurs_boules"][4][3] = partie_info["couleurs_joueurs"][3]
    
    if  nombre_joueurs == 1 :
        partie_info["couleurs_boules"] = [[None for i in range(8)] for j in range(8)]
        while True :
            couleur_cpu = random.choice(["orange","red","yellow","green","blue","indigo","pink"])
            if couleur_cpu not in partie_info["couleurs_joueurs"] :
                break
            
        partie_info["couleurs_joueurs"][1] = couleur_cpu
        
        partie_info["couleurs_boules"][3][3] = partie_info["couleurs_joueurs"][0]
        partie_info["couleurs_boules"][3][4] = partie_info["couleurs_joueurs"][2]
        partie_info["couleurs_boules"][4][4] = partie_info["couleurs_joueurs"][1]
        partie_info["couleurs_boules"][4][3] = partie_info["couleurs_joueurs"][3]
        
        partie_info["noms_joueurs"][1] = "CPU"
        partie_info["nombre_joueurs"] = 2

    partie_info["score_total"] = [0 for i in range(partie_info["nombre_joueurs"])]
    partie_info["score_manche"] = [1 for i in range(partie_info["nombre_joueurs"])]

    if nombre_joueurs == 1 :
        partie_info["nombre_joueurs"] = 1
    
    partie_info["statut_manche"] = True
    partie_info["nombre_manches"] = 1
    partie_info["statut_partie"] = False
    
    partie_info["couleurs_boules_init"] = copy.deepcopy(partie_info["couleurs_boules"])
    
    sauvegarder_jeu(partie_info)
    
    return "jouer"

def charger_menu_options() :
    """
    Dessiner le menu des options
    """
    polygone_mode0 = [(taille_fenetre*0.130,taille_fenetre*0.080),(taille_fenetre*0.131,taille_fenetre*0.115),(taille_fenetre*0.133,taille_fenetre*0.130),(taille_fenetre*0.131,taille_fenetre*0.145),(taille_fenetre*0.130,taille_fenetre*0.180),(taille_fenetre*0.165,taille_fenetre*0.179),(taille_fenetre*0.180,taille_fenetre*0.177),(taille_fenetre*0.195,taille_fenetre*0.179),(taille_fenetre*0.230,taille_fenetre*0.180),(taille_fenetre*0.229,taille_fenetre*0.145),(taille_fenetre*0.227,taille_fenetre*0.130),(taille_fenetre*0.229,taille_fenetre*0.115),(taille_fenetre*0.230,taille_fenetre*0.080),(taille_fenetre*0.195,taille_fenetre*0.081),(taille_fenetre*0.180,taille_fenetre*0.083),(taille_fenetre*0.165,taille_fenetre*0.081),(taille_fenetre*0.130,taille_fenetre*0.080)] 
    polygone_mode1 = [(taille_fenetre*0.290,taille_fenetre*0.080),(taille_fenetre*0.291,taille_fenetre*0.115),(taille_fenetre*0.293,taille_fenetre*0.130),(taille_fenetre*0.291,taille_fenetre*0.145),(taille_fenetre*0.290,taille_fenetre*0.180),(taille_fenetre*0.325,taille_fenetre*0.179),(taille_fenetre*0.340,taille_fenetre*0.177),(taille_fenetre*0.355,taille_fenetre*0.179),(taille_fenetre*0.390,taille_fenetre*0.180),(taille_fenetre*0.389,taille_fenetre*0.145),(taille_fenetre*0.387,taille_fenetre*0.130),(taille_fenetre*0.389,taille_fenetre*0.115),(taille_fenetre*0.390,taille_fenetre*0.080),(taille_fenetre*0.355,taille_fenetre*0.081),(taille_fenetre*0.340,taille_fenetre*0.083),(taille_fenetre*0.325,taille_fenetre*0.081),(taille_fenetre*0.290,taille_fenetre*0.080)] 
    polygone_mode2 = [(taille_fenetre*0.130,taille_fenetre*0.310),(taille_fenetre*0.131,taille_fenetre*0.345),(taille_fenetre*0.133,taille_fenetre*0.360),(taille_fenetre*0.131,taille_fenetre*0.375),(taille_fenetre*0.130,taille_fenetre*0.410),(taille_fenetre*0.165,taille_fenetre*0.409),(taille_fenetre*0.180,taille_fenetre*0.407),(taille_fenetre*0.195,taille_fenetre*0.409),(taille_fenetre*0.230,taille_fenetre*0.410),(taille_fenetre*0.229,taille_fenetre*0.375),(taille_fenetre*0.227,taille_fenetre*0.360),(taille_fenetre*0.229,taille_fenetre*0.345),(taille_fenetre*0.230,taille_fenetre*0.310),(taille_fenetre*0.195,taille_fenetre*0.311),(taille_fenetre*0.180,taille_fenetre*0.313),(taille_fenetre*0.165,taille_fenetre*0.311),(taille_fenetre*0.130,taille_fenetre*0.310)]
    polygone_mode3 = [(taille_fenetre*0.290,taille_fenetre*0.310),(taille_fenetre*0.291,taille_fenetre*0.345),(taille_fenetre*0.293,taille_fenetre*0.360),(taille_fenetre*0.291,taille_fenetre*0.375),(taille_fenetre*0.290,taille_fenetre*0.410),(taille_fenetre*0.325,taille_fenetre*0.409),(taille_fenetre*0.340,taille_fenetre*0.407),(taille_fenetre*0.355,taille_fenetre*0.409),(taille_fenetre*0.390,taille_fenetre*0.410),(taille_fenetre*0.389,taille_fenetre*0.375),(taille_fenetre*0.387,taille_fenetre*0.360),(taille_fenetre*0.389,taille_fenetre*0.345),(taille_fenetre*0.390,taille_fenetre*0.310),(taille_fenetre*0.355,taille_fenetre*0.311),(taille_fenetre*0.340,taille_fenetre*0.313),(taille_fenetre*0.325,taille_fenetre*0.311),(taille_fenetre*0.290,taille_fenetre*0.310)] 

    def button_changer_theme() :
        """
        Afficher le button de changement du theme
        """
        if configuration["theme_interface"] == 1 :
            fltk.rectangle(taille_fenetre*0.800,taille_fenetre*0.290,taille_fenetre*0.900,taille_fenetre*0.390,'black','#FAF9D0')
            fltk.cercle(taille_fenetre*0.850,taille_fenetre*0.340,taille_fenetre*0.030,'black','black')
            fltk.cercle(taille_fenetre*0.845,taille_fenetre*0.335,taille_fenetre*0.027,'#FAF9D0','#FAF9D0')
        else :
            fltk.rectangle(taille_fenetre*0.800,taille_fenetre*0.290,taille_fenetre*0.900,taille_fenetre*0.390,'white','#010014')
            fltk.cercle(taille_fenetre*0.850,taille_fenetre*0.340,taille_fenetre*0.015,'white','white')
     
            fltk.cercle(taille_fenetre*0.850,taille_fenetre*0.310,taille_fenetre*0.003,'white','white')
            fltk.cercle(taille_fenetre*0.850,taille_fenetre*0.370,taille_fenetre*0.003,'white','white')
            fltk.cercle(taille_fenetre*0.825,taille_fenetre*0.340,taille_fenetre*0.003,'white','white')
            fltk.cercle(taille_fenetre*0.875,taille_fenetre*0.340,taille_fenetre*0.003,'white','white')
            
            fltk.cercle(taille_fenetre*0.870,taille_fenetre*0.360,taille_fenetre*0.003,'white','white')
            fltk.cercle(taille_fenetre*0.870,taille_fenetre*0.320,taille_fenetre*0.003,'white','white')
            fltk.cercle(taille_fenetre*0.830,taille_fenetre*0.360,taille_fenetre*0.003,'white','white')
            fltk.cercle(taille_fenetre*0.830,taille_fenetre*0.320,taille_fenetre*0.003,'white','white')

    def dessiner_boules_plateau(x,y,mode) :
        if mode == 0 :
            cercle_exterieure_couleur = 'black'
            cercle_exterieure_remplissage = '#828282'
            cercle_interieure_couleur = 'black'
            cercle_interieure_remplissage = 'black'
        if mode == 1 :
            cercle_exterieure_couleur = 'black'
            cercle_exterieure_remplissage = '#BFBFBF'
            cercle_interieure_couleur = 'black'
            cercle_interieure_remplissage = '#606060'
        if mode == 2 :
            cercle_exterieure_couleur = '#AAAAAA'
            cercle_exterieure_remplissage = 'black'
            cercle_interieure_couleur = '#AAAAAA'
            cercle_interieure_remplissage = '#050505'

        debut_y = y + taille_fenetre*0.008
        for i in range(8) :
            debut_x = x + taille_fenetre*0.008
            for j in range(8) :
                fltk.cercle(debut_x, debut_y, taille_fenetre*0.004,cercle_exterieure_couleur,cercle_exterieure_remplissage)
                fltk.cercle(debut_x, debut_y, taille_fenetre*0.0025,cercle_interieure_couleur,cercle_interieure_remplissage)
                debut_x += taille_fenetre*0.012
            debut_y += taille_fenetre*0.012

    def changement_theme_interface() :
        fltk.efface_tout()
        charger_menu_options()

    def dessiner_cercle(x,y,rayon,mode) :
        if mode == 0 :
            fltk.cercle(x,y,rayon,'#B90F12','#B90F12')  
            fltk.cercle(x,y-1,rayon-2,'#E61D24','#E61D24')
            fltk.cercle(x-3,y-5,rayon-12,'#EE4A4B','#EE4A4B')
            fltk.cercle(x-6,y-14,rayon/4,'#F36C69','#F36C69')
            fltk.cercle(x-12,y+3,rayon/6,'#F36C69','#F36C69')
        
        if mode == 1 :
            fltk.cercle(x, y, rayon+4, 'black', 'black', 1)
            fltk.cercle(x, y-8, rayon-4, 'black', '#F8E666', 1)
            fltk.cercle(x-8, y+6, rayon-6, 'black', '#3C9CCE', 1)
            fltk.cercle(x+8, y+6, rayon-6, 'black', '#369E35', 1)
            fltk.cercle(x,y,rayon,'#B90F12','#B90F12')
            fltk.cercle(x,y-rayon/36,rayon-2*rayon/36,'#E61D24','#E61D24')
            fltk.cercle(x-3*rayon/36,y-5*rayon/36,rayon-12*rayon/36,'#EE4A4B','#EE4A4B')
            fltk.cercle(x-6*rayon/36,y-14*rayon/36,rayon/(4*rayon/36),'#F36C69','#F36C69')
            fltk.cercle(x-12*rayon/36,y+3*rayon/36,rayon/(6*rayon/36),'#F36C69','#F36C69')

    if configuration["theme_interface"] == 1 : #010014 17202A
        fltk.rectangle(0,0,taille_fenetre,hauteur_fenetre,'#010014','#010014')
        couleur_trait = 'white'
        couleur_inverse = 'black'
    if configuration["theme_interface"] == 0 :
        fltk.rectangle(0,0,taille_fenetre,hauteur_fenetre,'#F1E3A4','#F1E3A4')
        couleur_trait = 'black'
        couleur_inverse = 'white'

    fltk.cercle(taille_fenetre*0.180,taille_fenetre*0.130,taille_fenetre*0.055,couleur_trait,'#828282')
    fltk.polygone(polygone_mode0,couleur_trait,'#828282')
    dessiner_boules_plateau(taille_fenetre*0.130,taille_fenetre*0.080,0)

    fltk.cercle(taille_fenetre*0.340,taille_fenetre*0.130,taille_fenetre*0.055,couleur_trait,'#DDDDDD')
    fltk.polygone(polygone_mode1,couleur_trait,'#DDDDDD')
    dessiner_boules_plateau(taille_fenetre*0.290,taille_fenetre*0.080,1)

    fltk.cercle(taille_fenetre*0.180,taille_fenetre*0.360,taille_fenetre*0.055,couleur_trait,'#F7DC6F')
    fltk.polygone(polygone_mode2,couleur_trait,'#F4D03F')
    dessiner_boules_plateau(taille_fenetre*0.130,taille_fenetre*0.310,1)

    fltk.cercle(taille_fenetre*0.340,taille_fenetre*0.360,taille_fenetre*0.055,couleur_trait,'black')
    fltk.polygone(polygone_mode3,couleur_trait,'black')
    dessiner_boules_plateau(taille_fenetre*0.290,taille_fenetre*0.310,2)

    #button à revenir au menu
    fltk.rectangle(taille_fenetre*0.300,taille_fenetre*0.930,taille_fenetre*0.700,taille_fenetre*1.030,couleur_trait,couleur_inverse)
    fltk.texte(taille_fenetre*0.500, taille_fenetre*0.980, IU_TEXTE['menu_options_menu'][configuration["index_langue"]], couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]], taille=int(taille_fenetre*0.024))

    fltk.texte(taille_fenetre*0.660, taille_fenetre*0.550, IU_TEXTE['menu_options_langue'][configuration["index_langue"]], couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.022))
    fltk.texte(taille_fenetre*0.680, taille_fenetre*0.610, IU_LANGUE[0], couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.016))
    fltk.rectangle(taille_fenetre*0.600,taille_fenetre*0.600,taille_fenetre*0.620,taille_fenetre*0.620,couleur_trait,couleur_inverse,taille_fenetre*0.003)
    fltk.texte(taille_fenetre*0.680, taille_fenetre*0.670, IU_LANGUE[1], couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.016))
    fltk.rectangle(taille_fenetre*0.600,taille_fenetre*0.660,taille_fenetre*0.620,taille_fenetre*0.680,couleur_trait,couleur_inverse,taille_fenetre*0.003)
    fltk.texte(taille_fenetre*0.680, taille_fenetre*0.730, IU_LANGUE[2], couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.016))
    fltk.rectangle(taille_fenetre*0.600,taille_fenetre*0.720,taille_fenetre*0.620,taille_fenetre*0.740,couleur_trait,couleur_inverse,taille_fenetre*0.003)
    fltk.texte(taille_fenetre*0.680, taille_fenetre*0.790, IU_LANGUE[3], couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.016))
    fltk.rectangle(taille_fenetre*0.600,taille_fenetre*0.780,taille_fenetre*0.620,taille_fenetre*0.800,couleur_trait,couleur_inverse,taille_fenetre*0.003)
    fltk.texte(taille_fenetre*0.680, taille_fenetre*0.850, IU_LANGUE[4], couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.016))
    fltk.rectangle(taille_fenetre*0.600,taille_fenetre*0.840,taille_fenetre*0.620,taille_fenetre*0.860,couleur_trait,couleur_inverse,taille_fenetre*0.003)

    fltk.texte(taille_fenetre*0.850, taille_fenetre*0.550, IU_TEXTE['menu_options_police'][configuration["index_langue"]], couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.022))
    fltk.texte(taille_fenetre*0.870, taille_fenetre*0.610, POLICE_FONTS[0], couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[0],taille=int(taille_fenetre*0.016))
    fltk.rectangle(taille_fenetre*0.790,taille_fenetre*0.600,taille_fenetre*0.810,taille_fenetre*0.620,couleur_trait,couleur_inverse,taille_fenetre*0.003)
    fltk.texte(taille_fenetre*0.870, taille_fenetre*0.670, POLICE_FONTS[1], couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[1],taille=int(taille_fenetre*0.016))
    fltk.rectangle(taille_fenetre*0.790,taille_fenetre*0.660,taille_fenetre*0.810,taille_fenetre*0.680,couleur_trait,couleur_inverse,taille_fenetre*0.003)
    fltk.texte(taille_fenetre*0.880, taille_fenetre*0.730, POLICE_FONTS[2], couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[2],taille=int(taille_fenetre*0.016))
    fltk.rectangle(taille_fenetre*0.790,taille_fenetre*0.720,taille_fenetre*0.810,taille_fenetre*0.740,couleur_trait,couleur_inverse,taille_fenetre*0.003)
    fltk.texte(taille_fenetre*0.870, taille_fenetre*0.790, POLICE_FONTS[3], couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[3],taille=int(taille_fenetre*0.016))
    fltk.rectangle(taille_fenetre*0.790,taille_fenetre*0.780,taille_fenetre*0.810,taille_fenetre*0.800,couleur_trait,couleur_inverse,taille_fenetre*0.003)
    fltk.texte(taille_fenetre*0.885, taille_fenetre*0.850, POLICE_FONTS[4], couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[4],taille=int(taille_fenetre*0.016))
    fltk.rectangle(taille_fenetre*0.790,taille_fenetre*0.840,taille_fenetre*0.810,taille_fenetre*0.860,couleur_trait,couleur_inverse,taille_fenetre*0.003)

    dessiner_forme(0,taille_fenetre*0.500,taille_fenetre*0.130,taille_fenetre*0.036,"orange")
    dessiner_forme(1,taille_fenetre*0.660,taille_fenetre*0.130,taille_fenetre*0.036,"blue")
    dessiner_forme(2,taille_fenetre*0.500,taille_fenetre*0.360,taille_fenetre*0.044,"red")
    dessiner_forme(3,taille_fenetre*0.660,taille_fenetre*0.350,taille_fenetre*0.090,"indigo")

    fltk.texte(taille_fenetre*0.850,taille_fenetre*0.435,IU_TEXTE['menu_options_theme'][configuration["index_langue"]],couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.016))

    fltk.texte(taille_fenetre*0.300,taille_fenetre*0.650,'ROLIT',couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.078))
    fltk.texte(taille_fenetre*0.300,taille_fenetre*0.730,'2025',couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.036))

    fltk.rectangle(taille_fenetre*0.170,taille_fenetre*0.210,taille_fenetre*0.190,taille_fenetre*0.230,couleur_trait,couleur_inverse,taille_fenetre*0.003)
    fltk.rectangle(taille_fenetre*0.330,taille_fenetre*0.210,taille_fenetre*0.350,taille_fenetre*0.230,couleur_trait,couleur_inverse,taille_fenetre*0.003)
    fltk.rectangle(taille_fenetre*0.490,taille_fenetre*0.210,taille_fenetre*0.510,taille_fenetre*0.230,couleur_trait,couleur_inverse,taille_fenetre*0.003)
    fltk.rectangle(taille_fenetre*0.650,taille_fenetre*0.210,taille_fenetre*0.670,taille_fenetre*0.230,couleur_trait,couleur_inverse,taille_fenetre*0.003)

    fltk.rectangle(taille_fenetre*0.170,taille_fenetre*0.440,taille_fenetre*0.190,taille_fenetre*0.460,couleur_trait,couleur_inverse,taille_fenetre*0.003)
    fltk.rectangle(taille_fenetre*0.330,taille_fenetre*0.440,taille_fenetre*0.350,taille_fenetre*0.460,couleur_trait,couleur_inverse,taille_fenetre*0.003)
    fltk.rectangle(taille_fenetre*0.490,taille_fenetre*0.440,taille_fenetre*0.510,taille_fenetre*0.460,couleur_trait,couleur_inverse,taille_fenetre*0.003)
    fltk.rectangle(taille_fenetre*0.650,taille_fenetre*0.440,taille_fenetre*0.670,taille_fenetre*0.460,couleur_trait,couleur_inverse,taille_fenetre*0.003)

    button_changer_theme()
    
    while True :
        if configuration["theme_interface"] == 0 :
            couleur_selectionne = 'black'
            couleur_non_selectionne = 'white'
        else :
            couleur_selectionne = 'white'
            couleur_non_selectionne = 'black'
            
        SELECTION_LANGUE_POLICE_CENTRES =  [taille_fenetre*0.610,taille_fenetre*0.670,taille_fenetre*0.730,taille_fenetre*0.790,taille_fenetre*0.850]
        SELECTION_MUSIC_FX_GRAPH =  [[taille_fenetre*0.440,taille_fenetre*0.320],[taille_fenetre*0.550,taille_fenetre*0.610,taille_fenetre*0.670]]
        SELECTION_PLATEAU = [[taille_fenetre*0.180,taille_fenetre*0.220],[taille_fenetre*0.340,taille_fenetre*0.220],[taille_fenetre*0.180,taille_fenetre*0.450],[taille_fenetre*0.340,taille_fenetre*0.450]]
        SELECTION_FORME = [[taille_fenetre*0.500,taille_fenetre*0.220],[taille_fenetre*0.660,taille_fenetre*0.220],[taille_fenetre*0.500,taille_fenetre*0.450],[taille_fenetre*0.660,taille_fenetre*0.450]]
        
        selection_plateau = fltk.cercle(SELECTION_PLATEAU[configuration["mode_plateau"]][0],SELECTION_PLATEAU[configuration["mode_plateau"]][1],taille_fenetre*0.007,couleur_selectionne,couleur_selectionne)
        selection_forme = fltk.cercle(SELECTION_FORME[configuration["mode_boules"]][0],SELECTION_FORME[configuration["mode_boules"]][1],taille_fenetre*0.007,couleur_selectionne,couleur_selectionne)

        selection_langue = fltk.cercle(taille_fenetre*0.610,SELECTION_LANGUE_POLICE_CENTRES[configuration["index_langue"]],taille_fenetre*0.007,couleur_selectionne,couleur_selectionne)
        selection_police = fltk.cercle(taille_fenetre*0.800,SELECTION_LANGUE_POLICE_CENTRES[configuration["index_police"]],taille_fenetre*0.007,couleur_selectionne,couleur_selectionne)
    
        clic = fltk.attend_ev()
        ty_clic = fltk.type_ev(clic)
        
        if ty_clic == "ClicGauche" :        
            if taille_fenetre*0.210 <= fltk.ordonnee_souris() <= taille_fenetre*0.230 :
                if taille_fenetre*0.170 <= fltk.abscisse_souris() <= taille_fenetre*0.190 :
                    configuration["mode_plateau"] = 0
                elif taille_fenetre*0.330 <= fltk.abscisse_souris() <= taille_fenetre*0.350 :
                    configuration["mode_plateau"] = 1
                elif taille_fenetre*0.490 <= fltk.abscisse_souris() <= taille_fenetre*0.510 :
                    configuration["mode_boules"] = 0
                elif taille_fenetre*0.650 <= fltk.abscisse_souris() <= taille_fenetre*0.670 :
                    configuration["mode_boules"] = 1
            
            elif taille_fenetre*0.290 <= fltk.ordonnee_souris() <= taille_fenetre*0.390 :
                if taille_fenetre*0.800 <= fltk.abscisse_souris() <= taille_fenetre*0.900 :
                    if configuration["theme_interface"] == 0 :
                        configuration["theme_interface"] = 1
                        couleur_selectionne = 'black'
                        changement_theme_interface()
                    elif configuration["theme_interface"] == 1 :
                        configuration["theme_interface"] = 0
                        couleur_selectionne = 'white'
                        if configuration["mode_plateau"] == 3 :
                            configuration["mode_plateau"] = 0
                        changement_theme_interface()
            
            elif taille_fenetre*0.440 <= fltk.ordonnee_souris() <= taille_fenetre*0.460 :
                if taille_fenetre*0.170 <= fltk.abscisse_souris() <= taille_fenetre*0.190 :
                    configuration["mode_plateau"] = 2
                elif taille_fenetre*0.330 <= fltk.abscisse_souris() <= taille_fenetre*0.350 :
                    if configuration["theme_interface"] == 1 :
                        configuration["mode_plateau"] = 3
                elif taille_fenetre*0.490 <= fltk.abscisse_souris() <= taille_fenetre*0.510 :
                    configuration["mode_boules"] = 2
                elif taille_fenetre*0.650 <= fltk.abscisse_souris() <= taille_fenetre*0.670 :
                    configuration["mode_boules"] = 3
                    
            elif taille_fenetre*0.600 <= fltk.ordonnee_souris() <= taille_fenetre*0.620 :
                if taille_fenetre*0.600 <= fltk.abscisse_souris() <= taille_fenetre*0.620 :
                    configuration["index_langue"] = 0
                elif taille_fenetre*0.790 <= fltk.abscisse_souris() <= taille_fenetre*0.810 :
                    configuration["index_police"] = 0
                    
            elif taille_fenetre*0.660 <= fltk.ordonnee_souris() <= taille_fenetre*0.680 :
                if taille_fenetre*0.600 <= fltk.abscisse_souris() <= taille_fenetre*0.620 :
                    configuration["index_langue"] = 1
                elif taille_fenetre*0.790 <= fltk.abscisse_souris() <= taille_fenetre*0.810 :
                    configuration["index_police"] = 1
                
            elif taille_fenetre*0.720 <= fltk.ordonnee_souris() <= taille_fenetre*0.740 :
                if taille_fenetre*0.600 <= fltk.abscisse_souris() <= taille_fenetre*0.620 :
                    configuration["index_langue"] = 2
                elif taille_fenetre*0.790 <= fltk.abscisse_souris() <= taille_fenetre*0.810 :
                    configuration["index_police"] = 2
                    
            elif taille_fenetre*0.780 <= fltk.ordonnee_souris() <= taille_fenetre*0.800 :
                if taille_fenetre*0.600 <= fltk.abscisse_souris() <= taille_fenetre*0.620 :
                    configuration["index_langue"] = 3
                elif taille_fenetre*0.790 <= fltk.abscisse_souris() <= taille_fenetre*0.810 :
                    configuration["index_police"] = 3
                    
            elif taille_fenetre*0.840 <= fltk.ordonnee_souris() <= taille_fenetre*0.860 :
                if taille_fenetre*0.600 <= fltk.abscisse_souris() <= taille_fenetre*0.620 :
                    configuration["index_langue"] = 4
                elif taille_fenetre*0.790 <= fltk.abscisse_souris() <= taille_fenetre*0.810 :
                    configuration["index_police"] = 4
                    
            elif taille_fenetre*0.930 <= fltk.ordonnee_souris() <= taille_fenetre*1.030 :
                if taille_fenetre*0.300 <= fltk.abscisse_souris() <= taille_fenetre*0.700 :
                    return "menu"

            fltk.efface(selection_plateau)
            fltk.efface(selection_forme)
            
            fltk.efface(selection_langue)
            fltk.efface(selection_police)
            
            sauvegarder_config(configuration)
            
            fltk.mise_a_jour()      
        
        elif ty_clic == "Quitte" :
            return "quitter"

def charger_menu_principal() :
    """
    Dessiner le menu principal
    """
    fltk.efface_tout()
    if configuration["theme_interface"] == 1 :
        fltk.rectangle(0,0,taille_fenetre,hauteur_fenetre,'#010014','#010014')
        couleur_trait = 'white'
        couleur_inverse = 'black'
    if configuration["theme_interface"] == 0 :
        fltk.rectangle(0,0,taille_fenetre,hauteur_fenetre,'#F1E3A4','#F1E3A4')
        couleur_trait = 'black'
        couleur_inverse = 'white'
    
    partie_info = restaurer_jeu()
    
    fltk.texte(taille_fenetre*0.500,taille_fenetre*0.175, 'ROLIT', couleur=couleur_trait, ancrage='center', police="Centaur",taille=int(taille_fenetre*0.110))
    fltk.texte(taille_fenetre*0.500,taille_fenetre*0.275, 'V1.0 - 2025', couleur=couleur_trait, ancrage='center', police="Centaur",taille=int(taille_fenetre*0.040))
    
    if restaurer_jeu() != None :
        if not partie_info["statut_partie"] :
            fltk.rectangle(taille_fenetre*0.350,taille_fenetre*0.350,taille_fenetre*0.650,taille_fenetre*0.450,couleur_trait,couleur_inverse)
            fltk.texte(taille_fenetre*0.500,taille_fenetre*0.400, IU_TEXTE['menu_principal_reprendre'][configuration["index_langue"]], couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.024))
    
    fltk.rectangle(taille_fenetre*0.350,taille_fenetre*0.500,taille_fenetre*0.650,taille_fenetre*0.600,couleur_trait,couleur_inverse)
    fltk.texte(taille_fenetre*0.500,taille_fenetre*0.550, IU_TEXTE['menu_principal_jouer'][configuration["index_langue"]], couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.024))
    
    fltk.rectangle(taille_fenetre*0.350,taille_fenetre*0.650,taille_fenetre*0.650,taille_fenetre*0.750,couleur_trait,couleur_inverse)
    fltk.texte(taille_fenetre*0.500,taille_fenetre*0.700, IU_TEXTE['menu_principal_options'][configuration["index_langue"]], couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.024))
    
    fltk.rectangle(taille_fenetre*0.350,taille_fenetre*0.800,taille_fenetre*0.650,taille_fenetre*0.900,couleur_trait,couleur_inverse)
    fltk.texte(taille_fenetre*0.500,taille_fenetre*0.850, IU_TEXTE['menu_principal_quitter'][configuration["index_langue"]], couleur=couleur_trait, ancrage='center', police=POLICE_FONTS[configuration["index_police"]],taille=int(taille_fenetre*0.024))
    
    while True :
        clic = fltk.attend_ev()
        ty_clic = fltk.type_ev(clic)
        
        if ty_clic == "ClicGauche" :
            if taille_fenetre*0.350 <= fltk.abscisse_souris() <= taille_fenetre*0.650 :
                if taille_fenetre*0.350 <= fltk.ordonnee_souris() <= taille_fenetre*0.450 :
                    if restaurer_jeu() != None :
                        if not partie_info["statut_partie"] :
                            return "reprendre"
                elif taille_fenetre*0.500 <= fltk.ordonnee_souris() <= taille_fenetre*0.600 :
                    return "prepartie"
                elif taille_fenetre*0.650 <= fltk.ordonnee_souris() <= taille_fenetre*0.750 :
                    return "options"
                elif taille_fenetre*0.800 <= fltk.ordonnee_souris() <= taille_fenetre*0.900 :
                    return "quitter"
        
        elif ty_clic == "Quitte" :
            return "quitter"

def main() :
    """
    Fonction main
    """
    fltk.cree_fenetre(taille_fenetre,taille_fenetre*1.1)
    fenetre = "menu"
    while True :
        if fenetre == "menu" :
            fenetre = charger_menu_principal()
        elif fenetre == "options" :
            fenetre = charger_menu_options()
        elif fenetre == "prepartie" :
            fenetre = charger_menu_prepartie()
        elif fenetre == "reprendre" :
            fenetre = partie()
        elif fenetre == "jouer" :
            fenetre = partie()
        elif fenetre == "quitter" :
            break

#++++++++++++++++++++++++++++++++++++++++++++++++++++#
#--------------- PROGRAMME PRINCIPAL ----------------#
#++++++++++++++++++++++++++++++++++++++++++++++++++++#

if __name__ == "__main__":
    main()
            
    fltk.ferme_fenetre()
    quit()